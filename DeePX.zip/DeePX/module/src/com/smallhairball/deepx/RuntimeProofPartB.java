package com.smallhairball.deepx;
final class RuntimeProofPartB {
    static byte[] material() { return null; }
    private RuntimeProofPartB() {}
}
