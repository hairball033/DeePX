public final class lq {}
