package com.smallhairball.deepx;

import android.app.Activity;

final class CommunityUi {
    private CommunityUi() {}
    static void open(Activity act) {}
}
