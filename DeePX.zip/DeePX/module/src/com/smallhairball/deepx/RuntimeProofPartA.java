package com.smallhairball.deepx;
final class RuntimeProofPartA {
    static byte[] material() { return null; }
    private RuntimeProofPartA() {}
}
