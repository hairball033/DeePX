package com.smallhairball.deepx.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.combinedClickable
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.input.rememberTextFieldState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowRight
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.outlined.Devices
import androidx.compose.material.icons.rounded.Build
import androidx.compose.material.icons.rounded.BlurOn
import androidx.compose.material.icons.rounded.CheckCircleOutline
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material.icons.rounded.Style
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import top.yukonga.miuix.kmp.basic.Card
import top.yukonga.miuix.kmp.basic.CardDefaults
import top.yukonga.miuix.kmp.basic.ButtonDefaults
import top.yukonga.miuix.kmp.basic.Icon
import top.yukonga.miuix.kmp.basic.IconButton
import top.yukonga.miuix.kmp.basic.MiuixScrollBehavior
import top.yukonga.miuix.kmp.basic.Scaffold
import top.yukonga.miuix.kmp.basic.Slider
import top.yukonga.miuix.kmp.basic.Switch
import top.yukonga.miuix.kmp.basic.Text
import top.yukonga.miuix.kmp.basic.TextButton
import top.yukonga.miuix.kmp.basic.TextField
import top.yukonga.miuix.kmp.basic.TopAppBar
import top.yukonga.miuix.kmp.overlay.OverlayDialog
import top.yukonga.miuix.kmp.theme.MiuixTheme
import top.yukonga.miuix.kmp.theme.darkColorScheme
import top.yukonga.miuix.kmp.theme.lightColorScheme
import top.yukonga.miuix.kmp.utils.PressFeedbackType
import top.yukonga.miuix.kmp.utils.overScrollVertical
import top.yukonga.miuix.kmp.utils.scrollEndHaptic
import top.yukonga.miuix.kmp.window.WindowDialog

/** One tappable entry on the injected home page. [id] is handed back to the Java side. */
data class HostEntry(
    val id: String,
    val title: String,
    val subtitle: String,
    val icon: ImageVector,
)

/** Snapshot of everything the in-host Miuix page needs, filled by [DeePXHostLauncher]. */
data class HostHomeInfo(
    val active: Boolean = true,
    val moduleVersion: String = "",
    val xposedInterface: String = "",
    val buildDate: String = "",
    val deepSeekVersion: String = "",
    val deviceRows: List<Pair<String, String>> = emptyList(),
    val entries: List<HostEntry> = emptyList(),
    val licenseText: String = "",
    val repositoryUrl: String = "",
)

/**
 * Root of the in-host Miuix UI. Runs inside the injected DeepSeek process via [DeePXHostLauncher]
 * and reproduces the legacy View home: a search box, a list of category entries and an "About"
 * page with activation/build/device details. Entry taps are forwarded back to Java so the original
 * feature pages keep working.
 */
@Composable
fun MiuixTestApp(
    info: HostHomeInfo,
    onEntry: (String) -> Unit = {},
    onClose: () -> Unit = {},
) {
    val darkMode = isSystemInDarkTheme()
    MiuixTheme(colors = if (darkMode) darkColorScheme() else lightColorScheme()) {
        // The injected process is not a ComponentActivity, so several Compose owners are missing.
        // OverlayDialog (via Miuix) needs a NavigationEventDispatcherOwner for its back handling.
        val navOwner = androidx.navigationevent.compose.rememberNavigationEventDispatcherOwner(
            enabled = true,
            parent = null,
        )
        androidx.compose.runtime.CompositionLocalProvider(
            androidx.navigationevent.compose.LocalNavigationEventDispatcherOwner provides navOwner
        ) {
            // A single root Scaffold hosts every OverlayDialog (its MiuixPopupHost renders the
            // popups in the current window, so dialogs get the real Miuix look and animation
            // instead of a separate platform window). It must not add its own insets or padding;
            // the inner pages handle those.
            Scaffold(
                modifier = Modifier.fillMaxSize(),
                contentWindowInsets = androidx.compose.foundation.layout.WindowInsets(0),
            ) { _ ->
                MiuixHostPage(info = info, onEntry = onEntry, onClose = onClose)
            }
        }
    }
}

/** Id of the built-in About entry; handled entirely inside the Compose layer. */
internal const val ABOUT_ID = "__about__"

/** Id of the Open-source licence entry; handled entirely inside the Compose layer. */
internal const val LICENSE_ID = "license"

/** Id of the community entry; the dialog is Compose-side, the QQ action returns to Java. */
internal const val COMMUNITY_ID = "community"

/** Id of the Help entry; handled entirely inside the Compose layer. */
internal const val HELP_ID = "help"

/** Id of the Chat category entry; handled entirely inside the Compose layer. */
internal const val CHAT_ID = "chat"

/** Id of the Account category entry; handled entirely inside the Compose layer. */
internal const val ACCOUNT_ID = "account"

/** Id of the Appearance category entry; handled entirely inside the Compose layer. */
internal const val APPEARANCE_ID = "appearance"

/** Id of the Debug category entry; handled entirely inside the Compose layer. */
internal const val DEBUG_ID = "debug"

/** Id of the Engineering category entry; handled entirely inside the Compose layer. */
internal const val ENGINEERING_ID = "engineering"

/** Id sent back to Java to open the QQ group link. */
internal const val QQ_GROUP_ACTION_ID = "__open_qq_group__"

@Composable
private fun MiuixHostPage(
    info: HostHomeInfo,
    onEntry: (String) -> Unit,
    onClose: () -> Unit,
) {
    var showLicense by remember { mutableStateOf(false) }
    var showCommunity by remember { mutableStateOf(false) }
    var page by remember { mutableStateOf(HostPage.Home) }
    var forward by remember { mutableStateOf(true) }

    // System back / gesture: pop the current sub-page back to Home; on Home the dialog's own
    // fallback callback (set in DeePXHostLauncher) closes the whole page.
    androidx.activity.compose.BackHandler(enabled = page != HostPage.Home) {
        forward = false
        page = HostPage.Home
    }
    androidx.activity.compose.BackHandler(enabled = showLicense) { showLicense = false }
    androidx.activity.compose.BackHandler(enabled = showCommunity) { showCommunity = false }

    LicenseWindowDialog(
        info = info,
        show = showLicense,
        onClose = { showLicense = false },
    )
    CommunityWindowDialog(
        show = showCommunity,
        onClose = { showCommunity = false },
        onOpenQq = { onEntry(QQ_GROUP_ACTION_ID) },
    )

    AnimatedContent(
        targetState = page,
        transitionSpec = {
            // Traditional Activity push: forward slides in from the right, back slides in from
            // the left, with the outgoing page moving in the opposite direction.
            if (forward) {
                (slideInHorizontally { it } + fadeIn()) togetherWith
                    (slideOutHorizontally { -it } + fadeOut())
            } else {
                (slideInHorizontally { -it } + fadeIn()) togetherWith
                    (slideOutHorizontally { it } + fadeOut())
            }
        },
        label = "hostPage",
    ) { target ->
        when (target) {
            HostPage.Home -> HomePage(
                info = info,
                onEntry = { id ->
                    when (id) {
                        ABOUT_ID -> { forward = true; page = HostPage.About }
                        LICENSE_ID -> showLicense = true
                        COMMUNITY_ID -> showCommunity = true
                        HELP_ID -> { forward = true; page = HostPage.Help }
                        CHAT_ID -> { forward = true; page = HostPage.Chat }
                        ACCOUNT_ID -> { forward = true; page = HostPage.Account }
                        APPEARANCE_ID -> { forward = true; page = HostPage.Appearance }
                        DEBUG_ID -> { forward = true; page = HostPage.Debug }
                        ENGINEERING_ID -> { forward = true; page = HostPage.Engineering }
                        else -> onEntry(id)
                    }
                },
                onClose = onClose,
            )

            HostPage.About -> AboutPage(
                info = info,
                onBack = { forward = false; page = HostPage.Home },
            )

            HostPage.Help -> HelpPage(
                onBack = { forward = false; page = HostPage.Home },
            )

            HostPage.Chat -> ChatPage(
                onBack = { forward = false; page = HostPage.Home },
            )

            HostPage.Account -> AccountPage(
                onBack = { forward = false; page = HostPage.Home },
                onOpenAccounts = { forward = true; page = HostPage.Accounts },
            )

            HostPage.Accounts -> AccountsPage(
                onBack = { forward = false; page = HostPage.Account },
            )

            HostPage.Appearance -> AppearancePage(
                onBack = { forward = false; page = HostPage.Home },
                onOpenSettings = { forward = true; page = HostPage.AppearanceSettings },
            )

            HostPage.AppearanceSettings -> AppearanceSettingsPage(
                onBack = { forward = false; page = HostPage.Appearance },
            )

            HostPage.Debug -> DebugPage(
                onBack = { forward = false; page = HostPage.Home },
            )

            HostPage.Engineering -> EngineeringPage(
                onBack = { forward = false; page = HostPage.Home },
                onOpenGrayFlags = { forward = true; page = HostPage.FeatureFlags },
                onOpenAgent = { forward = true; page = HostPage.Agent },
                onOpenJavaPlugin = { forward = true; page = HostPage.JavaPlugin },
                onOpenProcess = { forward = true; page = HostPage.ProcessManager },
            )

            HostPage.FeatureFlags -> FeatureFlagsPage(
                onBack = { forward = false; page = HostPage.Engineering },
            )

            HostPage.Agent -> AgentPage(
                onBack = { forward = false; page = HostPage.Engineering },
                onOpenRuns = { forward = true; page = HostPage.AgentRuns },
                onOpenAdvanced = { forward = true; page = HostPage.AgentAdvanced },
                onOpenMcp = { forward = true; page = HostPage.Mcp },
            )

            HostPage.AgentRuns -> AgentRunsPage(
                onBack = { forward = false; page = HostPage.Agent },
            )

            HostPage.AgentAdvanced -> AgentAdvancedPage(
                onBack = { forward = false; page = HostPage.Agent },
            )

            HostPage.Mcp -> McpPage(
                onBack = { forward = false; page = HostPage.Agent },
            )

            HostPage.JavaPlugin -> JavaPluginPage(
                onBack = { forward = false; page = HostPage.Engineering },
                onOpenHooks = { forward = true; page = HostPage.HookCatalog },
            )

            HostPage.HookCatalog -> HookCatalogPage(
                onBack = { forward = false; page = HostPage.JavaPlugin },
            )

            HostPage.ProcessManager -> ProcessManagerPage(
                onBack = { forward = false; page = HostPage.Engineering },
            )
        }
    }
}

/** Pages hosted inside the injected DeepSeek process. */
private enum class HostPage { Home, About, Help, Chat, Account, Accounts, Appearance, AppearanceSettings, Debug, Engineering, FeatureFlags, Agent, AgentRuns, AgentAdvanced, Mcp, JavaPlugin, HookCatalog, ProcessManager }

/**
 * Community dialog rendered with Miuix's [WindowDialog]. The QQ action is delegated back to Java so
 * the share link stays defined in a single place.
 */
@Composable
private fun CommunityWindowDialog(
    show: Boolean,
    onClose: () -> Unit,
    onOpenQq: () -> Unit,
) {
    OverlayDialog(
        title = "加入交流群",
        show = show,
        onDismissRequest = onClose,
    ) {
        TextButton(
            text = "QQ：DeePX 模块交流群",
            onClick = {
                onOpenQq()
                onClose()
            },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.textButtonColorsPrimary(),
        )
    }
}

/**
 * Open-source licence dialog rendered with Miuix's [WindowDialog] so it matches the rest of the
 * in-host HyperOS-style UI. Stays mounted and is controlled by [show] so the open/close animations
 * play; the two actions follow Miuix's standard side-by-side text-button layout.
 */
@Composable
private fun LicenseWindowDialog(
    info: HostHomeInfo,
    show: Boolean,
    onClose: () -> Unit,
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val body = info.licenseText.ifBlank { "GNU General Public License version 3" }
    OverlayDialog(
        title = "GNU General Public License v3.0",
        show = show,
        onDismissRequest = onClose,
    ) {
        Text(
            text = body,
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(max = 320.dp)
                .verticalScroll(rememberScrollState())
                .padding(bottom = 12.dp),
            style = MiuixTheme.textStyles.body2,
            color = MiuixTheme.colorScheme.onSurfaceVariantSummary,
        )
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            TextButton(
                text = "GitHub",
                onClick = {
                    runCatching {
                        context.startActivity(
                            android.content.Intent(
                                android.content.Intent.ACTION_VIEW,
                                android.net.Uri.parse(info.repositoryUrl),
                            )
                        )
                    }
                    onClose()
                },
                modifier = Modifier.weight(1f),
            )
            Spacer(Modifier.width(20.dp))
            TextButton(
                text = "关闭",
                onClick = onClose,
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.textButtonColorsPrimary(),
            )
        }
    }
}

@Composable
private fun HomePage(
    info: HostHomeInfo,
    onEntry: (String) -> Unit,
    onClose: () -> Unit,
) {
    val scrollBehavior = MiuixScrollBehavior()
    val colorScheme = MiuixTheme.colorScheme
    val searchState = rememberTextFieldState("")

    val query = searchState.text.toString()
    val visibleEntries = if (query.isBlank()) info.entries
    else info.entries.filter {
        it.title.contains(query, ignoreCase = true) ||
            it.subtitle.contains(query, ignoreCase = true)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = "DeePX Ultra",
                subtitle = "1.0.0 Beta",
                navigationIcon = {
                    IconButton(onClick = onClose) {
                        Icon(
                            Icons.AutoMirrored.Rounded.ArrowBack,
                            contentDescription = "返回",
                            tint = colorScheme.onBackground,
                        )
                    }
                },
                scrollBehavior = scrollBehavior,
            )
        },
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxHeight()
                .scrollEndHaptic()
                .overScrollVertical()
                .nestedScroll(scrollBehavior.nestedScrollConnection)
                .padding(horizontal = 12.dp),
            contentPadding = PaddingValues(
                top = innerPadding.calculateTopPadding() + 8.dp,
                bottom = innerPadding.calculateBottomPadding() + 24.dp,
            ),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            overscrollEffect = null,
        ) {
            item {
                TextField(
                    state = searchState,
                    label = "搜索功能",
                    modifier = Modifier.fillMaxWidth(),
                )
            }

            if (visibleEntries.isEmpty()) {
                item {
                    Text(
                        text = "没有找到相关功能",
                        modifier = Modifier.padding(16.dp),
                        style = MiuixTheme.textStyles.body2,
                        color = colorScheme.onSurfaceVariantSummary,
                    )
                }
            } else {
                items(visibleEntries, key = { it.id }) { entry ->
                    EntryRow(
                        entry = entry,
                        onClick = { onEntry(entry.id) },
                    )
                }
            }

            item {
                Text(
                    text = "模块版本：${info.moduleVersion}\n" +
                        "Xposed 接口：${info.xposedInterface}\n" +
                        "编译时间：${info.buildDate}\n" +
                        "DeepSeek 版本：${info.deepSeekVersion}",
                    modifier = Modifier.fillMaxWidth().padding(8.dp, 4.dp, 8.dp, 4.dp),
                    style = MiuixTheme.textStyles.body2,
                    color = colorScheme.onSurfaceVariantSummary,
                )
            }
        }
    }
}

@Composable
private fun EntryRow(entry: HostEntry, onClick: () -> Unit) {
    val colorScheme = MiuixTheme.colorScheme
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        showIndication = true,
        pressFeedbackType = PressFeedbackType.Sink,
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(
                imageVector = entry.icon,
                contentDescription = null,
                tint = colorScheme.primary,
                modifier = Modifier.size(24.dp),
            )
            Spacer(Modifier.width(16.dp))
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(2.dp),
            ) {
                Text(entry.title, style = MiuixTheme.textStyles.title4)
                if (entry.subtitle.isNotBlank()) {
                    Text(
                        text = entry.subtitle,
                        style = MiuixTheme.textStyles.body2,
                        color = colorScheme.onSurfaceVariantSummary,
                    )
                }
            }
            Icon(
                imageVector = Icons.AutoMirrored.Rounded.KeyboardArrowRight,
                contentDescription = null,
                tint = colorScheme.onSurfaceVariantSummary,
                modifier = Modifier.size(20.dp),
            )
        }
    }
}

@Composable
private fun AboutPage(info: HostHomeInfo, onBack: () -> Unit) {
    val scrollBehavior = MiuixScrollBehavior()
    val colorScheme = MiuixTheme.colorScheme

    Scaffold(
        topBar = {
            TopAppBar(
                title = "DeePX Ultra",
                subtitle = "关于",
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            Icons.AutoMirrored.Rounded.ArrowBack,
                            contentDescription = "返回",
                            tint = colorScheme.onBackground,
                        )
                    }
                },
                scrollBehavior = scrollBehavior,
            )
        },
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxHeight()
                .scrollEndHaptic()
                .overScrollVertical()
                .nestedScroll(scrollBehavior.nestedScrollConnection)
                .padding(horizontal = 12.dp),
            contentPadding = PaddingValues(
                top = innerPadding.calculateTopPadding() + 12.dp,
                bottom = innerPadding.calculateBottomPadding() + 24.dp,
            ),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            overscrollEffect = null,
        ) {
            item { ActivationCard(active = info.active) }

            item {
                InfoPanel(
                    icon = Icons.Filled.Info,
                    rows = listOf(
                        "模块版本" to info.moduleVersion,
                        "Xposed 接口" to info.xposedInterface,
                        "编译时间" to info.buildDate,
                        "DeepSeek 版本" to info.deepSeekVersion,
                    ),
                )
            }

            if (info.deviceRows.isNotEmpty()) {
                item { InfoPanel(icon = Icons.Outlined.Devices, rows = info.deviceRows) }
            }

            item {
                Text(
                    text = "由于原模块 Deekseep 作者因为压力问题闭源、停更，且最后开源代码未适配新版 DeepSeek。因此，我创建了此项目来继续保持开源维护并增强。",
                    modifier = Modifier.fillMaxWidth().padding(8.dp),
                    style = MiuixTheme.textStyles.body2,
                    color = colorScheme.onSurfaceVariantSummary,
                )
            }
        }
    }
}

/** One expandable help entry: a question/feature title plus a body shown when expanded. */
private data class HelpEntry(val title: String, val body: String)

private val HELP_ENTRIES = listOf(
    HelpEntry("【功能】系统提示词注入", "把选定的提示词附加到请求中。"),
    HelpEntry("【功能】心跳与定时提醒", "按当前对话发送主动消息，并可设置或取消提醒。"),
    HelpEntry("【功能】Agent 工具", "在实验性功能中管理工具和权限，支持基础操作。"),
    HelpEntry("【功能】工具调用日志", "显示工具名称、调用时间和执行结果。"),
    HelpEntry("【功能】问答工具", "模型提出选项或问题，你选择或输入后继续对话。"),
    HelpEntry("【功能】面板与图形输出", "模型可生成信息面板、进度条和简单图形。"),
    HelpEntry("【功能】聊天外观", "自定义气泡、背景图、贴纸和透明度。"),
    HelpEntry("【功能】本地 API", "提供兼容接口和本地 Agent 工具调用。"),
    HelpEntry("【问题】工具只显示文字，没有真正执行？", "确认实验性功能中的 Agent 开关已开启，并检查工具权限。"),
    HelpEntry("【问题】心跳提醒没有出现在对话？", "确认已绑定目标对话，并允许通知和后台运行。"),
    HelpEntry("【问题】背景图或聊天外观没有生效？", "重新打开对应页面；部分设置需要重启 DeepSeek。"),
    HelpEntry("【问题】编辑或历史记录显示异常？", "先在 DeepSeek 原生页面打开目标对话并等待加载，再重试。"),
    HelpEntry("【问题】账号导入失败？", "使用完整 UTF-8 JSON，并确认凭证仍有效。"),
)

/**
 * Help page rendered with Miuix: a collapsible accordion of feature/how-to entries, matching the
 * look of the rest of the in-host UI. Tapping a row expands its body inline.
 */
@Composable
private fun HelpPage(onBack: () -> Unit) {
    val scrollBehavior = MiuixScrollBehavior()
    val colorScheme = MiuixTheme.colorScheme
    var expandedIndex by remember { mutableStateOf(-1) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = "DeePX Ultra",
                subtitle = "帮助与问题",
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            Icons.AutoMirrored.Rounded.ArrowBack,
                            contentDescription = "返回",
                            tint = colorScheme.onBackground,
                        )
                    }
                },
                scrollBehavior = scrollBehavior,
            )
        },
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxHeight()
                .scrollEndHaptic()
                .overScrollVertical()
                .nestedScroll(scrollBehavior.nestedScrollConnection)
                .padding(horizontal = 12.dp),
            contentPadding = PaddingValues(
                top = innerPadding.calculateTopPadding() + 12.dp,
                bottom = innerPadding.calculateBottomPadding() + 24.dp,
            ),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            overscrollEffect = null,
        ) {
            item {
                Text(
                    text = "功能说明与常见问题",
                    modifier = Modifier.padding(start = 4.dp, top = 4.dp),
                    style = MiuixTheme.textStyles.footnote1,
                    color = colorScheme.onSurfaceVariantSummary,
                )
            }
            items(HELP_ENTRIES.size, key = { it }) { index ->
                val entry = HELP_ENTRIES[index]
                HelpCard(
                    entry = entry,
                    expanded = expandedIndex == index,
                    onToggle = {
                        expandedIndex = if (expandedIndex == index) -1 else index
                    },
                )
            }
        }
    }
}

/** A single tappable help card that reveals its body when [expanded]. */
@Composable
private fun HelpCard(entry: HelpEntry, expanded: Boolean, onToggle: () -> Unit) {
    val colorScheme = MiuixTheme.colorScheme
    Card(
        onClick = onToggle,
        modifier = Modifier.fillMaxWidth(),
        showIndication = true,
        pressFeedbackType = PressFeedbackType.Sink,
    ) {
        Column(modifier = Modifier.fillMaxWidth().padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = entry.title,
                    modifier = Modifier.weight(1f),
                    style = MiuixTheme.textStyles.title4,
                )
                Icon(
                    imageVector = Icons.AutoMirrored.Rounded.KeyboardArrowRight,
                    contentDescription = null,
                    tint = colorScheme.onSurfaceVariantSummary,
                    modifier = Modifier.size(20.dp),
                )
            }
            if (expanded) {
                Spacer(Modifier.height(8.dp))
                Text(
                    text = entry.body,
                    style = MiuixTheme.textStyles.body2,
                    color = colorScheme.onSurfaceVariantSummary,
                )
            }
        }
    }
}

/** One row on the Chat page, as delivered by [ChatPageBridge]. */
private class ChatRow(
    val id: String,
    val title: String,
    subtitle: String,
    val isSwitch: Boolean,
    val isTask: Boolean,
    val hasGear: Boolean,
    checked: Boolean,
) {
    var subtitle: String by mutableStateOf(subtitle)
    var checked by mutableStateOf(checked)
}

/**
 * Chat category page rendered with Miuix. All state and actions are delegated to
 * {@code com.smallhairball.deepx.ChatPageBridge}, so this layer only draws Miuix widgets.
 */
@Composable
private fun ChatPage(onBack: () -> Unit) {
    val scrollBehavior = MiuixScrollBehavior()
    val colorScheme = MiuixTheme.colorScheme
    val context = androidx.compose.ui.platform.LocalContext.current
    var showSearch by remember { mutableStateOf(false) }

    val rows = remember {
        runCatching {
            com.smallhairball.deepx.ChatPageBridge.setContext(context)
            com.smallhairball.deepx.ChatPageBridge.rows().map { r ->
                ChatRow(
                    id = r.id,
                    title = r.title,
                    subtitle = r.subtitle,
                    isSwitch = r.type == com.smallhairball.deepx.ChatPageBridge.TYPE_SWITCH,
                    isTask = r.type == com.smallhairball.deepx.ChatPageBridge.TYPE_TASK,
                    hasGear = false,
                    checked = r.checked,
                )
            }
        }.getOrDefault(emptyList())
    }

    ChatSearchDialog(show = showSearch, onClose = { showSearch = false })

    Scaffold(
        topBar = {
            TopAppBar(
                title = "DeePX Ultra",
                subtitle = "聊天",
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            Icons.AutoMirrored.Rounded.ArrowBack,
                            contentDescription = "返回",
                            tint = colorScheme.onBackground,
                        )
                    }
                },
                scrollBehavior = scrollBehavior,
            )
        },
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxHeight()
                .scrollEndHaptic()
                .overScrollVertical()
                .nestedScroll(scrollBehavior.nestedScrollConnection)
                .padding(horizontal = 12.dp),
            contentPadding = PaddingValues(
                top = innerPadding.calculateTopPadding() + 12.dp,
                bottom = innerPadding.calculateBottomPadding() + 24.dp,
            ),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            overscrollEffect = null,
        ) {
            item(key = "__import_prompt__") {
                PromptImportHeader(
                    path = remember {
                        runCatching { com.smallhairball.deepx.ChatPageBridge.promptPath() }
                            .getOrDefault("")
                    },
                    onImport = {
                        runCatching {
                            com.smallhairball.deepx.ChatPageBridge.action(
                                context as? android.app.Activity, "import_prompt",
                            )
                        }
                    },
                    onReset = {
                        runCatching {
                            com.smallhairball.deepx.ChatPageBridge.action(
                                context as? android.app.Activity, "reset_prompt",
                            )
                        }
                    },
                )
            }
            items(rows.size, key = { rows[it].id }) { index ->
                val row = rows[index]
                ChatRowCard(
                    row = row,
                    onToggle = {
                        val next = runCatching {
                            com.smallhairball.deepx.ChatPageBridge.toggle(row.id)
                        }.getOrDefault(row.checked)
                        row.checked = next
                    },
                    onOpen = {
                        if (row.id == "global_search") {
                            showSearch = true
                        } else {
                            runCatching {
                                com.smallhairball.deepx.ChatPageBridge.action(
                                    context as? android.app.Activity, row.id,
                                )
                            }
                        }
                    },
                )
            }
        }
    }
}

/** Header block with the system-prompt import button / path and the red "还原设置" action. */
@Composable
private fun PromptImportHeader(path: String, onImport: () -> Unit, onReset: () -> Unit) {
    val colorScheme = MiuixTheme.colorScheme
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            TextButton(
                text = "导入提示词",
                onClick = onImport,
                colors = ButtonDefaults.textButtonColorsPrimary(),
            )
            if (path.isNotBlank()) {
                Spacer(Modifier.height(8.dp))
                Text(
                    text = path,
                    style = MiuixTheme.textStyles.footnote1,
                    color = colorScheme.onSurfaceVariantSummary,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                )
            }
            Spacer(Modifier.height(12.dp))
            TextButton(
                text = "还原设置",
                onClick = onReset,
                modifier = Modifier.fillMaxWidth(),
            )
        }
    }
}

/** A single row: a switch row or a link row, both drawn as Miuix cards. */
@Composable
private fun ChatRowCard(
    row: ChatRow,
    onToggle: () -> Unit,
    onOpen: () -> Unit,
    extraAction: (() -> Unit)? = null,
) {
    val colorScheme = MiuixTheme.colorScheme
    Card(
        onClick = { if (row.isSwitch) onToggle() else onOpen() },
        modifier = Modifier.fillMaxWidth(),
        showIndication = true,
        pressFeedbackType = PressFeedbackType.Sink,
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(2.dp),
            ) {
                Text(row.title, style = MiuixTheme.textStyles.title4)
                if (row.subtitle.isNotBlank()) {
                    Text(
                        text = row.subtitle,
                        style = MiuixTheme.textStyles.body2,
                        color = colorScheme.onSurfaceVariantSummary,
                    )
                }
            }
            when {
                row.isSwitch -> top.yukonga.miuix.kmp.basic.Switch(
                    checked = row.checked,
                    onCheckedChange = { onToggle() },
                )
                row.isTask -> TextButton(
                    text = "执行",
                    onClick = onOpen,
                )
                else -> Icon(
                    imageVector = Icons.AutoMirrored.Rounded.KeyboardArrowRight,
                    contentDescription = null,
                    tint = colorScheme.onSurfaceVariantSummary,
                    modifier = Modifier.size(20.dp),
                )
            }
            if (extraAction != null) {
                IconButton(onClick = extraAction) {
                    Icon(
                        imageVector = Icons.Rounded.Style,
                        contentDescription = "设置",
                        tint = colorScheme.onSurfaceVariantSummary,
                        modifier = Modifier.size(20.dp),
                    )
                }
            }
        }
    }
}

/** One search hit mirrored into Compose. */
private class SearchHit(
    val sid: String,
    val title: String,
    val source: String,
    val account: String,
    val snippet: String,
)

/**
 * Global chat-history search rendered with Miuix. Query and search state live here; the actual
 * database scan and native navigation are delegated to {@code ChatSearchBridge}.
 */
@Composable
private fun ChatSearchDialog(show: Boolean, onClose: () -> Unit) {
    val colorScheme = MiuixTheme.colorScheme
    val context = androidx.compose.ui.platform.LocalContext.current
    val textState = androidx.compose.foundation.text.input.rememberTextFieldState("")
    var allAccounts by remember { mutableStateOf(false) }
    var searching by remember { mutableStateOf(false) }
    var searched by remember { mutableStateOf(false) }
    var hits by remember { mutableStateOf(listOf<SearchHit>()) }

    OverlayDialog(
        title = "搜索聊天记录",
        show = show,
        onDismissRequest = onClose,
    ) {
        top.yukonga.miuix.kmp.basic.TextField(
            state = textState,
            label = "输入关键词",
            modifier = Modifier.fillMaxWidth(),
        )
        Spacer(Modifier.height(8.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                text = "搜索全部账号",
                modifier = Modifier.weight(1f),
                style = MiuixTheme.textStyles.body2,
                color = colorScheme.onSurfaceVariantSummary,
            )
            top.yukonga.miuix.kmp.basic.Switch(
                checked = allAccounts,
                onCheckedChange = { allAccounts = it },
            )
        }
        Spacer(Modifier.height(12.dp))

        if (searched) {
            Text(
                text = if (hits.isEmpty()) "未找到相关记录"
                else "命中 ${hits.size} 条",
                style = MiuixTheme.textStyles.footnote1,
                color = colorScheme.onSurfaceVariantSummary,
            )
            Spacer(Modifier.height(8.dp))
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 320.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                hits.forEach { hit ->
                    Card(
                        onClick = {
                            runCatching {
                                com.smallhairball.deepx.ChatSearchBridge.openHit(
                                    context as? android.app.Activity, hit.sid,
                                )
                            }
                            onClose()
                        },
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Column(modifier = Modifier.fillMaxWidth().padding(12.dp)) {
                            val meta = buildString {
                                if (hit.account.isNotBlank()) append(hit.account).append(" · ")
                                append(hit.source).append(" · ").append(hit.title)
                            }
                            Text(
                                text = meta,
                                style = MiuixTheme.textStyles.footnote1,
                                color = colorScheme.onSurfaceVariantSummary,
                                maxLines = 1,
                            )
                            Spacer(Modifier.height(4.dp))
                            Text(
                                text = hit.snippet,
                                style = MiuixTheme.textStyles.body2,
                                maxLines = 3,
                            )
                        }
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            TextButton(
                text = "关闭",
                onClick = onClose,
                modifier = Modifier.weight(1f),
            )
            Spacer(Modifier.width(20.dp))
            TextButton(
                text = if (searching) "搜索中…" else "搜索",
                onClick = {
                    val keyword = textState.text.toString().trim()
                    if (keyword.isEmpty()) return@TextButton
                    searching = true
                    searched = false
                    runCatching {
                        com.smallhairball.deepx.ChatSearchBridge.search(
                            context as? android.app.Activity,
                            keyword,
                            allAccounts,
                        ) { result ->
                            hits = result.map { h ->
                                SearchHit(
                                    sid = h.sid,
                                    title = h.title,
                                    source = h.source,
                                    account = h.account.orEmpty(),
                                    snippet = h.snippet,
                                )
                            }
                            searching = false
                            searched = true
                        }
                    }.onFailure {
                        searching = false
                        searched = true
                    }
                },
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.textButtonColorsPrimary(),
            )
        }
    }
}

/**
 * Account &amp; privacy category page rendered with Miuix. State and actions are delegated to
 * {@code com.smallhairball.deepx.AccountPageBridge}.
 */
@Composable
private fun AccountPage(onBack: () -> Unit, onOpenAccounts: () -> Unit) {
    val scrollBehavior = MiuixScrollBehavior()
    val colorScheme = MiuixTheme.colorScheme
    val context = androidx.compose.ui.platform.LocalContext.current
    var showFakeMute by remember { mutableStateOf(false) }

    val rows = remember {
        runCatching {
            com.smallhairball.deepx.AccountPageBridge.setContext(context)
            com.smallhairball.deepx.AccountPageBridge.rows().map { r ->
                ChatRow(
                    id = r.id,
                    title = r.title,
                    subtitle = r.subtitle,
                    isSwitch = r.type == com.smallhairball.deepx.AccountPageBridge.TYPE_SWITCH,
                    isTask = false,
                    hasGear = false,
                    checked = r.checked,
                )
            }
        }.getOrDefault(emptyList())
    }

    FakeMuteDialog(show = showFakeMute, onClose = { showFakeMute = false })

    Scaffold(
        topBar = {
            TopAppBar(
                title = "DeePX Ultra",
                subtitle = "账号与隐私",
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            Icons.AutoMirrored.Rounded.ArrowBack,
                            contentDescription = "返回",
                            tint = colorScheme.onBackground,
                        )
                    }
                },
                scrollBehavior = scrollBehavior,
            )
        },
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxHeight()
                .scrollEndHaptic()
                .overScrollVertical()
                .nestedScroll(scrollBehavior.nestedScrollConnection)
                .padding(horizontal = 12.dp),
            contentPadding = PaddingValues(
                top = innerPadding.calculateTopPadding() + 12.dp,
                bottom = innerPadding.calculateBottomPadding() + 24.dp,
            ),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            overscrollEffect = null,
        ) {
            items(rows.size, key = { rows[it].id }) { index ->
                val row = rows[index]
                ChatRowCard(
                    row = row,
                    onToggle = {
                        if (row.id == "anti_ban") {
                            runCatching {
                                com.smallhairball.deepx.AccountPageBridge.action(
                                    context as? android.app.Activity, row.id,
                                )
                            }
                        } else {
                            val next = runCatching {
                                com.smallhairball.deepx.AccountPageBridge.toggle(row.id)
                            }.getOrDefault(row.checked)
                            row.checked = next
                            if (row.id == "fake_mute") {
                                row.subtitle = runCatching {
                                    com.smallhairball.deepx.AccountPageBridge.fakeMuteDetail()
                                }.getOrDefault(row.subtitle)
                            }
                        }
                    },
                    onOpen = {
                        if (row.id == "fake_mute") {
                            showFakeMute = true
                        } else if (row.id == "accounts") {
                            onOpenAccounts()
                        } else {
                            runCatching {
                                com.smallhairball.deepx.AccountPageBridge.action(
                                    context as? android.app.Activity, row.id,
                                )
                            }
                        }
                    },
                    extraAction = if (row.id == "fake_mute") {
                        { showFakeMute = true }
                    } else null,
                )
            }
        }
    }
}

/**
 * Local-mute deadline picker rendered with Miuix. Offers quick presets instead of a full calendar;
 * the deadline and enable state are handled by {@code AccountPageBridge}.
 */
@Composable
private fun FakeMuteDialog(show: Boolean, onClose: () -> Unit) {
    val colorScheme = MiuixTheme.colorScheme
    val secondsState = androidx.compose.foundation.text.input.rememberTextFieldState("")
    var error by remember { mutableStateOf("") }

    OverlayDialog(
        title = "本地禁言 · 设置截止时间",
        show = show,
        onDismissRequest = onClose,
    ) {
        Text(
            text = "输入从现在起持续的秒数，例如 3600（1 小时）。",
            style = MiuixTheme.textStyles.footnote1,
            color = colorScheme.onSurfaceVariantSummary,
        )
        Spacer(Modifier.height(10.dp))
        top.yukonga.miuix.kmp.basic.TextField(
            state = secondsState,
            label = "秒数",
            modifier = Modifier.fillMaxWidth(),
        )
        if (error.isNotBlank()) {
            Spacer(Modifier.height(8.dp))
            Text(
                text = error,
                style = MiuixTheme.textStyles.footnote1,
                color = colorScheme.error,
            )
        }
        Spacer(Modifier.height(12.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            TextButton(
                text = "清除",
                onClick = {
                    runCatching {
                        com.smallhairball.deepx.AccountPageBridge.setFakeMuteDeadline(0L)
                    }
                    onClose()
                },
                modifier = Modifier.weight(1f),
            )
            Spacer(Modifier.width(20.dp))
            TextButton(
                text = "确定",
                onClick = {
                    val seconds = secondsState.text.toString().trim().toLongOrNull()
                    if (seconds == null || seconds <= 0L) {
                        error = "请输入大于 0 的整数秒数"
                        return@TextButton
                    }
                    runCatching {
                        com.smallhairball.deepx.AccountPageBridge.setFakeMuteDeadline(seconds * 1000L)
                    }
                    onClose()
                },
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.textButtonColorsPrimary(),
            )
        }
    }
}

/** One account mirrored into Compose. */
private class AccountItem(
    val id: String,
    val label: String,
    val provider: String,
    val current: Boolean,
)

/**
 * Multi-account page rendered with Miuix. Account listing, switching and the batch operations
 * (validate / export / delete / import / add) are delegated to {@code AccountsBridge}.
 */
@Composable
private fun AccountsPage(onBack: () -> Unit) {
    val scrollBehavior = MiuixScrollBehavior()
    val colorScheme = MiuixTheme.colorScheme
    val context = androidx.compose.ui.platform.LocalContext.current
    var accounts by remember {
        mutableStateOf(
            runCatching {
                com.smallhairball.deepx.AccountsBridge.list(context as? android.app.Activity)
                    .map { AccountItem(it.id, it.label, it.provider, it.current) }
            }.getOrDefault(emptyList())
        )
    }
    var multiSelectMode by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf(setOf<String>()) }
    var showAdd by remember { mutableStateOf(false) }
    var showPassword by remember { mutableStateOf(false) }

    fun refresh() {
        accounts = runCatching {
            com.smallhairball.deepx.AccountsBridge.list(context as? android.app.Activity)
                .map { AccountItem(it.id, it.label, it.provider, it.current) }
        }.getOrDefault(accounts)
    }

    AddAccountDialog(
        show = showAdd,
        onClose = { showAdd = false },
        onPasswordLogin = {
            showAdd = false
            showPassword = true
        },
        onNativeLogin = {
            showAdd = false
            runCatching {
                com.smallhairball.deepx.AccountsBridge.nativeAdd(
                    context as? android.app.Activity,
                )
            }
        },
    )
    PasswordLoginDialog(
        show = showPassword,
        onClose = { showPassword = false },
        onSubmit = { identity, password, onResult ->
            runCatching {
                com.smallhairball.deepx.AccountsBridge.passwordAdd(
                    context as? android.app.Activity, identity, password,
                ) { success, message ->
                    onResult(success, message)
                    if (success) {
                        showPassword = false
                        refresh()
                    }
                }
            }
        },
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = "DeePX Ultra",
                subtitle = "多账号",
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            Icons.AutoMirrored.Rounded.ArrowBack,
                            contentDescription = "返回",
                            tint = colorScheme.onBackground,
                        )
                    }
                },
                actions = {
                    if (!multiSelectMode) {
                        TextButton(
                            text = "导入",
                            onClick = {
                                runCatching {
                                    com.smallhairball.deepx.AccountsBridge.importAccounts(
                                        context as? android.app.Activity,
                                    )
                                }
                                refresh()
                            },
                        )
                        TextButton(
                            text = "添加",
                            onClick = { showAdd = true },
                            colors = ButtonDefaults.textButtonColorsPrimary(),
                        )
                    }
                },
                scrollBehavior = scrollBehavior,
            )
        },
    ) { innerPadding ->
        Column(modifier = Modifier.fillMaxSize()) {
            if (multiSelectMode) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        text = "已选 ${selected.size}",
                        modifier = Modifier.weight(1f),
                        style = MiuixTheme.textStyles.title4,
                    )
                    TextButton(
                        text = if (selected.size == accounts.size) "取消全选" else "全选",
                        onClick = {
                            selected = if (selected.size == accounts.size) {
                                emptySet()
                            } else {
                                accounts.map { it.id }.toSet()
                            }
                        },
                    )
                    TextButton(
                        text = "校验",
                        onClick = {
                            runCatching {
                                com.smallhairball.deepx.AccountsBridge.validate(
                                    context as? android.app.Activity,
                                )
                            }
                        },
                    )
                    TextButton(
                        text = "导出",
                        onClick = {
                            runCatching {
                                com.smallhairball.deepx.AccountsBridge.export(
                                    context as? android.app.Activity, selected,
                                )
                            }
                        },
                    )
                    TextButton(
                        text = "删除",
                        onClick = {
                            runCatching {
                                com.smallhairball.deepx.AccountsBridge.delete(
                                    context as? android.app.Activity, selected,
                                )
                            }
                            multiSelectMode = false
                            selected = emptySet()
                            refresh()
                        },
                    )
                }
            }

            LazyColumn(
                modifier = Modifier
                    .fillMaxHeight()
                    .scrollEndHaptic()
                    .overScrollVertical()
                    .nestedScroll(scrollBehavior.nestedScrollConnection)
                    .padding(horizontal = 12.dp),
                contentPadding = PaddingValues(
                    top = innerPadding.calculateTopPadding() + 8.dp,
                    bottom = innerPadding.calculateBottomPadding() + 24.dp,
                ),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                overscrollEffect = null,
            ) {
                if (accounts.isEmpty()) {
                    item {
                        Text(
                            text = "未检测到已登录账号。请先在 DeepSeek 正常登录一个账号。",
                            modifier = Modifier.padding(16.dp),
                            style = MiuixTheme.textStyles.body2,
                            color = colorScheme.onSurfaceVariantSummary,
                        )
                    }
                } else {
                    items(accounts.size, key = { accounts[it].id }) { index ->
                        val account = accounts[index]
                        AccountRowCard(
                            account = account,
                            multiSelectMode = multiSelectMode,
                            selected = selected.contains(account.id),
                            onClick = {
                                if (multiSelectMode) {
                                    selected = if (selected.contains(account.id)) {
                                        selected - account.id
                                    } else {
                                        selected + account.id
                                    }
                                } else if (!account.current) {
                                    runCatching {
                                        com.smallhairball.deepx.AccountsBridge.switchTo(
                                            context as? android.app.Activity, account.id,
                                        )
                                    }
                                    refresh()
                                }
                            },
                            onLongClick = {
                                multiSelectMode = true
                                selected = setOf(account.id)
                            },
                        )
                    }
                }
            }
        }
    }
}

/**
 * "界面美化" (Appearance) category page rendered with Miuix. State and actions are delegated to
 * {@code com.smallhairball.deepx.AppearancePageBridge}.
 */
@Composable
private fun AppearancePage(onBack: () -> Unit, onOpenSettings: () -> Unit) {
    val scrollBehavior = MiuixScrollBehavior()
    val colorScheme = MiuixTheme.colorScheme
    val context = androidx.compose.ui.platform.LocalContext.current
    var showGreeting by remember { mutableStateOf(false) }
    var showWhaleSpeed by remember { mutableStateOf(false) }
    var showTextWaveSpeed by remember { mutableStateOf(false) }
    var showThemeColor by remember { mutableStateOf(false) }
    var showAvatar by remember { mutableStateOf(false) }

    val rows = remember {
        runCatching {
            com.smallhairball.deepx.AppearancePageBridge.rows().map { r ->
                ChatRow(
                    id = r.id,
                    title = r.title,
                    subtitle = r.subtitle,
                    isSwitch = r.type == com.smallhairball.deepx.AppearancePageBridge.TYPE_SWITCH,
                    isTask = false,
                    hasGear = r.hasGear,
                    checked = r.checked,
                )
            }
        }.getOrDefault(emptyList())
    }

    GreetingDialog(show = showGreeting, onClose = { showGreeting = false })
    SpeedDialog(
        show = showWhaleSpeed,
        title = "鲸鱼旋转速度",
        min = 0.1f, max = 1.0f,
        lowLabel = "0.1× 慢速", highLabel = "1.0× 快速",
        initial = remember { runCatching {
            com.smallhairball.deepx.AppearancePageBridge.whaleSpeed()
        }.getOrDefault(0.3f) },
        onSave = { com.smallhairball.deepx.AppearancePageBridge.setWhaleSpeed(it) },
        onClose = { showWhaleSpeed = false },
    )
    SpeedDialog(
        show = showTextWaveSpeed,
        title = "文字波纹速度",
        min = 0.2f, max = 1.5f,
        lowLabel = "0.2× 舒缓", highLabel = "1.5× 灵动",
        initial = remember { runCatching {
            com.smallhairball.deepx.AppearancePageBridge.textWaveSpeed()
        }.getOrDefault(0.6f) },
        onSave = { com.smallhairball.deepx.AppearancePageBridge.setTextWaveSpeed(it) },
        onClose = { showTextWaveSpeed = false },
    )
    ThemeColorDialog(show = showThemeColor, onClose = { showThemeColor = false })
    AssistantAvatarDialog(show = showAvatar, onClose = { showAvatar = false })

    Scaffold(
        topBar = {
            TopAppBar(
                title = "DeePX Ultra",
                subtitle = "界面美化",
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            Icons.AutoMirrored.Rounded.ArrowBack,
                            contentDescription = "返回",
                            tint = colorScheme.onBackground,
                        )
                    }
                },
                scrollBehavior = scrollBehavior,
            )
        },
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxHeight()
                .scrollEndHaptic()
                .overScrollVertical()
                .nestedScroll(scrollBehavior.nestedScrollConnection)
                .padding(horizontal = 12.dp),
            contentPadding = PaddingValues(
                top = innerPadding.calculateTopPadding() + 12.dp,
                bottom = innerPadding.calculateBottomPadding() + 24.dp,
            ),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            overscrollEffect = null,
        ) {
            items(rows.size, key = { rows[it].id }) { index ->
                val row = rows[index]
                ChatRowCard(
                    row = row,
                    onToggle = {
                        val next = runCatching {
                            com.smallhairball.deepx.AppearancePageBridge.toggle(row.id)
                        }.getOrDefault(row.checked)
                        row.checked = next
                    },
                    onOpen = {
                        when (row.id) {
                            "greeting" -> showGreeting = true
                            "assistant_avatar" -> showAvatar = true
                            "appearance" -> onOpenSettings()
                            else -> runCatching {
                                com.smallhairball.deepx.AppearancePageBridge.action(
                                    context as? android.app.Activity, row.id,
                                )
                            }
                        }
                    },
                    extraAction = if (row.hasGear) {
                        {
                            when (row.id) {
                                "whale_motion" -> showWhaleSpeed = true
                                "text_wave" -> showTextWaveSpeed = true
                                "theme_color" -> showThemeColor = true
                                else -> {}
                            }
                        }
                    } else null,
                )
            }
        }
    }
}

/**
 * "外观设置" (chat appearance) page rendered with Miuix. Every switch row is delegated to
 * {@code com.smallhairball.deepx.AppearanceSettingsBridge}; choice dialogs follow in later revisions.
 */
@Composable
private fun AppearanceSettingsPage(onBack: () -> Unit) {
    val scrollBehavior = MiuixScrollBehavior()
    val colorScheme = MiuixTheme.colorScheme
    val context = androidx.compose.ui.platform.LocalContext.current
    val rows = remember {
        runCatching {
            com.smallhairball.deepx.AppearanceSettingsBridge.rows().map { r ->
                ChatRow(
                    id = r.id,
                    title = r.title,
                    subtitle = r.subtitle,
                    isSwitch = r.type == com.smallhairball.deepx.AppearanceSettingsBridge.TYPE_SWITCH,
                    isTask = false,
                    hasGear = false,
                    checked = r.checked,
                )
            }
        }.getOrDefault(emptyList())
    }
    var choiceRow by remember { mutableStateOf<ChatRow?>(null) }
    var showImport by remember { mutableStateOf(false) }
    var showReset by remember { mutableStateOf(false) }
    var toast by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = "DeePX Ultra",
                subtitle = "外观设置",
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                            contentDescription = "返回",
                            tint = colorScheme.onBackground,
                            modifier = Modifier.size(20.dp),
                        )
                    }
                },
                scrollBehavior = scrollBehavior,
            )
        },
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxHeight()
                .scrollEndHaptic()
                .overScrollVertical()
                .nestedScroll(scrollBehavior.nestedScrollConnection)
                .padding(horizontal = 12.dp),
            contentPadding = PaddingValues(
                top = innerPadding.calculateTopPadding() + 12.dp,
                bottom = innerPadding.calculateBottomPadding() + 24.dp,
            ),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            overscrollEffect = null,
        ) {
            items(rows.size, key = { rows[it].id }) { index ->
                val row = rows[index]
                ChatRowCard(
                    row = row,
                    onToggle = {
                        val next = runCatching {
                            com.smallhairball.deepx.AppearanceSettingsBridge.toggle(row.id)
                        }.getOrDefault(row.checked)
                        row.checked = next
                    },
                    onOpen = {
                        when (row.id) {
                            "glass_quality", "spatial_strength", "bubble_style" -> choiceRow = row
                            "import_image" -> showImport = true
                            "reset" -> showReset = true
                            "preview" -> runCatching {
                                com.smallhairball.deepx.AppearanceSettingsBridge.openLegacyEditor(
                                    context as? android.app.Activity,
                                )
                            }
                            else -> runCatching {
                                com.smallhairball.deepx.AppearanceSettingsBridge.action(
                                    context as? android.app.Activity, row.id,
                                )
                            }
                        }
                    },
                    extraAction = null,
                )
            }
        }
    }

    val active = choiceRow
    if (active != null) {
        AppearanceChoiceDialog(
            row = active,
            onClose = { choiceRow = null },
            onSelected = { value ->
                runCatching {
                    com.smallhairball.deepx.AppearanceSettingsBridge.applyChoice(active.id, value)
                }
                active.subtitle = "当前: " + runCatching {
                    com.smallhairball.deepx.AppearanceSettingsBridge.currentChoice(active.id)
                }.getOrDefault("")
                choiceRow = null
            },
        )
    }

    if (showImport) {
        val colorScheme2 = MiuixTheme.colorScheme
        var importShow by remember { mutableStateOf(true) }
        OverlayDialog(
            title = "导入图片",
            show = importShow,
            onDismissRequest = { importShow = false },
            onDismissFinished = { showImport = false },
        ) {
            val roles = listOf(
                true to "设为背景图",
                false to "添加为页面贴纸",
            )
            roles.forEach { (background, label) ->
                Card(
                    onClick = {
                        importShow = false
                        runCatching {
                            com.smallhairball.deepx.AppearanceSettingsBridge.pickAndImport(
                                context as? android.app.Activity, background,
                            ) { ok, message ->
                                if (!ok) toast = message
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    showIndication = true,
                    pressFeedbackType = PressFeedbackType.Sink,
                ) {
                    Text(
                        text = label,
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 12.dp),
                        style = MiuixTheme.textStyles.title4,
                        color = colorScheme2.onSurface,
                    )
                }
                Spacer(Modifier.height(8.dp))
            }
        }
    }

    if (showReset) {
        ConfirmDialog(
            title = "重置全部聊天外观？",
            message = "背景图、全部贴纸、气泡样式和布局设置都会清除；聊天记录不会受到影响。",
            negativeLabel = "取消",
            positiveLabel = "重置",
            verticalButtons = false,
            onNegative = { showReset = false },
            onPositive = {
                showReset = false
                runCatching {
                    com.smallhairball.deepx.AppearanceSettingsBridge.resetAll()
                }
            },
            onDismissDialog = { showReset = false },
        )
    }

    if (toast.isNotBlank()) {
        val colorScheme3 = MiuixTheme.colorScheme
        var toastShow by remember { mutableStateOf(true) }
        OverlayDialog(
            title = "提示",
            show = toastShow,
            onDismissRequest = { toastShow = false },
            onDismissFinished = { toast = "" },
        ) {
            Text(
                text = toast,
                style = MiuixTheme.textStyles.body2,
                color = colorScheme3.onSurface,
            )
            Spacer(Modifier.height(12.dp))
            TextButton(
                text = "知道了",
                onClick = { toastShow = false },
                modifier = Modifier.fillMaxWidth(),
            )
        }
    }
}

/** Single-choice dialog for an appearance setting, rendered with Miuix. */
@Composable
private fun AppearanceChoiceDialog(
    row: ChatRow,
    onClose: () -> Unit,
    onSelected: (String) -> Unit,
) {
    val colorScheme = MiuixTheme.colorScheme
    val options = remember(row.id) {
        runCatching {
            com.smallhairball.deepx.AppearanceSettingsBridge.choices(row.id)
                .map { it.value to it.label }
        }.getOrDefault(emptyList())
    }
    val current = remember(row.id) {
        runCatching {
            com.smallhairball.deepx.AppearanceSettingsBridge.currentChoice(row.id)
        }.getOrDefault("")
    }
    var show by remember { mutableStateOf(true) }
    var pendingValue by remember { mutableStateOf<String?>(null) }

    OverlayDialog(
        title = row.title,
        show = show,
        onDismissRequest = { show = false },
        onDismissFinished = {
            val value = pendingValue
            if (value != null) onSelected(value) else onClose()
        },
    ) {
        options.forEach { (value, label) ->
            Card(
                onClick = { pendingValue = value; show = false },
                modifier = Modifier.fillMaxWidth(),
                showIndication = true,
                pressFeedbackType = PressFeedbackType.Sink,
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        text = label,
                        modifier = Modifier.weight(1f),
                        style = MiuixTheme.textStyles.title4,
                        color = colorScheme.onSurface,
                    )
                    if (value == current) {
                        Icon(
                            imageVector = Icons.Rounded.CheckCircleOutline,
                            contentDescription = null,
                            tint = colorScheme.primary,
                            modifier = Modifier.size(20.dp),
                        )
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
        }
    }
}

/**
 * "调试" (Debug) category page rendered with Miuix. Rows and actions are delegated to
 * {@code com.smallhairball.deepx.DebugPageBridge}; the raw-hook switch needs an explicit
 * risk acknowledgement dialog rendered on the Compose side.
 */
@Composable
private fun DebugPage(onBack: () -> Unit) {
    val scrollBehavior = MiuixScrollBehavior()
    val colorScheme = MiuixTheme.colorScheme
    val context = androidx.compose.ui.platform.LocalContext.current
    val rows = remember {
        runCatching {
            com.smallhairball.deepx.DebugPageBridge.rows().map { r ->
                ChatRow(
                    id = r.id,
                    title = r.title,
                    subtitle = r.subtitle,
                    isSwitch = r.type == com.smallhairball.deepx.DebugPageBridge.TYPE_SWITCH,
                    isTask = false,
                    hasGear = false,
                    checked = r.checked,
                )
            }
        }.getOrDefault(emptyList())
    }
    var showRawRisk by remember { mutableStateOf(false) }
    var reportTitle by remember { mutableStateOf("") }
    var reportBody by remember { mutableStateOf("") }
    var showLogExport by remember { mutableStateOf(false) }
    var crashReport by remember { mutableStateOf("") }
    var showCrashReport by remember { mutableStateOf(false) }
    var showCrashTests by remember { mutableStateOf(false) }
    var showRequest by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = "DeePX Ultra",
                subtitle = "调试",
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                            contentDescription = "返回",
                            tint = colorScheme.onBackground,
                            modifier = Modifier.size(20.dp),
                        )
                    }
                },
                scrollBehavior = scrollBehavior,
            )
        },
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxHeight()
                .scrollEndHaptic()
                .overScrollVertical()
                .nestedScroll(scrollBehavior.nestedScrollConnection)
                .padding(horizontal = 12.dp),
            contentPadding = PaddingValues(
                top = innerPadding.calculateTopPadding() + 12.dp,
                bottom = innerPadding.calculateBottomPadding() + 24.dp,
            ),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            overscrollEffect = null,
        ) {
            items(rows.size, key = { rows[it].id }) { index ->
                val row = rows[index]
                ChatRowCard(
                    row = row,
                    onToggle = {
                        if (row.id == "raw_hook" && !row.checked) {
                            showRawRisk = true
                        } else {
                            val next = runCatching {
                                com.smallhairball.deepx.DebugPageBridge.toggle(row.id)
                            }.getOrDefault(row.checked)
                            row.checked = next
                        }
                    },
                    onOpen = {
                        when (row.id) {
                            "compat_report", "perf_stats" -> {
                                reportTitle = row.title
                                reportBody = runCatching {
                                    com.smallhairball.deepx.DebugPageBridge.reportText(
                                        context as? android.app.Activity, row.id,
                                    )
                                }.getOrDefault("")
                            }
                            "log_export" -> showLogExport = true
                            "crash_records" -> {
                                crashReport = runCatching {
                                    com.smallhairball.deepx.DebugPageBridge.crashReport(
                                        context as? android.app.Activity,
                                    )
                                }.getOrDefault("")
                                showCrashReport = true
                            }
                            "crash_tests" -> showCrashTests = true
                            "custom_request" -> showRequest = true
                            else -> runCatching {
                                com.smallhairball.deepx.DebugPageBridge.action(
                                    context as? android.app.Activity, row.id,
                                )
                            }
                        }
                    },
                    extraAction = null,
                )
            }
        }
    }

    if (showRawRisk) {
        ConfirmDialog(
            title = "启用无脱敏日志？",
            message = "此功能会高频记录每个模块 Hook 的进入、参数、返回值、异常和耗时，并同步记录模块动作。内容完全不脱敏，可能包含聊天正文、账号、Token、Cookie、文件路径等敏感信息。\n\n日志仅自动保存在 DeepSeek 私有目录，单卷上限 64 MB、保留两卷。调试结束后请立即关闭并清理。",
            negativeLabel = "取消",
            positiveLabel = "理解风险并启用",
            verticalButtons = true,
            onNegative = { showRawRisk = false },
            onPositive = {
                showRawRisk = false
                val saved = runCatching {
                    com.smallhairball.deepx.DebugPageBridge.setRawHook(true)
                }.getOrDefault(false)
                rows.firstOrNull { it.id == "raw_hook" }?.checked = saved
            },
            onDismissDialog = { showRawRisk = false },
        )
    }

    if (reportBody.isNotBlank() || reportTitle.isNotBlank()) {
        val scheme = MiuixTheme.colorScheme
        var reportShow by remember(reportTitle) { mutableStateOf(true) }
        OverlayDialog(
            title = reportTitle,
            show = reportShow,
            onDismissRequest = { reportShow = false },
            onDismissFinished = { reportTitle = ""; reportBody = "" },
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 360.dp)
                    .verticalScroll(rememberScrollState()),
            ) {
                Text(
                    text = reportBody,
                    style = MiuixTheme.textStyles.body2,
                    color = scheme.onSurfaceVariantSummary,
                )
            }
            Spacer(Modifier.height(12.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                TextButton(
                    text = "复制",
                    onClick = {
                        runCatching {
                            com.smallhairball.deepx.DebugPageBridge.copyText(
                                context as? android.app.Activity, reportBody,
                            )
                        }
                    },
                    modifier = Modifier.weight(1f),
                )
                Spacer(Modifier.width(20.dp))
                TextButton(
                    text = "完成",
                    onClick = { reportShow = false },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.textButtonColorsPrimary(),
                )
            }
        }
    }

    if (showLogExport) {
        LogExportDialog(onClose = { showLogExport = false })
    }

    if (showCrashReport) {
        val scheme = MiuixTheme.colorScheme
        var crashShow by remember { mutableStateOf(true) }
        OverlayDialog(
            title = "记录崩溃",
            show = crashShow,
            onDismissRequest = { crashShow = false },
            onDismissFinished = { showCrashReport = false },
        ) {
            Text(
                text = "记录 Java 未捕获异常，并读取系统保留的 Native 崩溃与 ANR 记录。",
                style = MiuixTheme.textStyles.footnote1,
                color = scheme.onSurfaceVariantSummary,
            )
            Spacer(Modifier.height(10.dp))
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 320.dp)
                    .verticalScroll(rememberScrollState()),
            ) {
                Text(
                    text = crashReport.ifBlank { "暂无崩溃" },
                    style = MiuixTheme.textStyles.body2,
                    color = scheme.onSurfaceVariantSummary,
                )
            }
            Spacer(Modifier.height(12.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                TextButton(
                    text = "关闭",
                    onClick = { crashShow = false },
                    modifier = Modifier.weight(1f),
                )
                Spacer(Modifier.width(20.dp))
                TextButton(
                    text = "保存成文件",
                    onClick = {
                        runCatching {
                            com.smallhairball.deepx.DebugPageBridge.saveCrashReport(
                                context as? android.app.Activity, crashReport,
                            )
                        }
                        crashShow = false
                    },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.textButtonColorsPrimary(),
                )
            }
        }
    }

    if (showCrashTests) {
        CrashTestDialog(
            onClose = { showCrashTests = false },
            onTrigger = { mode ->
                showCrashTests = false
                runCatching {
                    com.smallhairball.deepx.DebugPageBridge.triggerCrash(
                        context as? android.app.Activity, mode,
                    )
                }
            },
        )
    }

    if (showRequest) {
        RequestDebugDialog(onClose = { showRequest = false })
    }
}

/**
 * "工程" (Engineering) category page rendered with Miuix. Rows and actions are delegated to
 * {@code com.smallhairball.deepx.EngineeringPageBridge}.
 */
@Composable
private fun EngineeringPage(onBack: () -> Unit, onOpenGrayFlags: () -> Unit, onOpenAgent: () -> Unit, onOpenJavaPlugin: () -> Unit, onOpenProcess: () -> Unit) {
    val scrollBehavior = MiuixScrollBehavior()
    val colorScheme = MiuixTheme.colorScheme
    val context = androidx.compose.ui.platform.LocalContext.current
    val rows = remember {
        runCatching {
            com.smallhairball.deepx.EngineeringPageBridge.rows(
                context as? android.app.Activity,
            ).map { r ->
                ChatRow(
                    id = r.id,
                    title = r.title,
                    subtitle = r.subtitle,
                    isSwitch = r.type == com.smallhairball.deepx.EngineeringPageBridge.TYPE_SWITCH,
                    isTask = r.type == com.smallhairball.deepx.EngineeringPageBridge.TYPE_TASK,
                    hasGear = r.hasGear,
                    checked = r.checked,
                )
            }
        }.getOrDefault(emptyList())
    }
    var showCacheGear by remember { mutableStateOf(false) }
    var showLanguage by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = "DeePX Ultra",
                subtitle = "工程",
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                            contentDescription = "返回",
                            tint = colorScheme.onBackground,
                            modifier = Modifier.size(20.dp),
                        )
                    }
                },
                scrollBehavior = scrollBehavior,
            )
        },
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxHeight()
                .scrollEndHaptic()
                .overScrollVertical()
                .nestedScroll(scrollBehavior.nestedScrollConnection)
                .padding(horizontal = 12.dp),
            contentPadding = PaddingValues(
                top = innerPadding.calculateTopPadding() + 12.dp,
                bottom = innerPadding.calculateBottomPadding() + 24.dp,
            ),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            overscrollEffect = null,
        ) {
            items(rows.size, key = { rows[it].id }) { index ->
                val row = rows[index]
                ChatRowCard(
                    row = row,
                    onToggle = {
                        val next = runCatching {
                            com.smallhairball.deepx.EngineeringPageBridge.toggle(row.id)
                        }.getOrDefault(row.checked)
                        row.checked = next
                    },
                    onOpen = {
                        when (row.id) {
                            "cache_cleaner" -> showCacheGear = true
                            "language" -> showLanguage = true
                            "gray_features" -> onOpenGrayFlags()
                            "agent" -> onOpenAgent()
                            "java_plugin" -> onOpenJavaPlugin()
                            "process_manager" -> onOpenProcess()
                            else -> runCatching {
                                com.smallhairball.deepx.EngineeringPageBridge.action(
                                    context as? android.app.Activity, row.id,
                                )
                            }
                        }
                    },
                    extraAction = if (row.hasGear) {
                        { showCacheGear = true }
                    } else null,
                )
            }
        }
    }

    if (showCacheGear) {
        CacheDaysDialog(onClose = { showCacheGear = false })
    }

    if (showLanguage) {
        LanguageDialog(onClose = { showLanguage = false })
    }
}

/** Cache-retention picker rendered with Miuix, backed by EngineeringPageBridge. */
@Composable
private fun CacheDaysDialog(onClose: () -> Unit) {
    val colorScheme = MiuixTheme.colorScheme
    val context = androidx.compose.ui.platform.LocalContext.current
    var show by remember { mutableStateOf(true) }
    val options = remember {
        runCatching {
            com.smallhairball.deepx.EngineeringPageBridge.cacheOptions()
        }.getOrDefault(emptyList())
    }
    val current = remember {
        runCatching {
            com.smallhairball.deepx.EngineeringPageBridge.currentCacheDays()
        }.getOrDefault(7)
    }

    OverlayDialog(
        title = "缓存保留时间",
        show = show,
        onDismissRequest = { show = false },
        onDismissFinished = onClose,
    ) {
        options.forEach { option ->
            Card(
                onClick = {
                    runCatching {
                        com.smallhairball.deepx.EngineeringPageBridge.setCacheDays(option.days)
                    }
                    show = false
                },
                modifier = Modifier.fillMaxWidth(),
                showIndication = true,
                pressFeedbackType = PressFeedbackType.Sink,
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        text = option.label,
                        modifier = Modifier.weight(1f),
                        style = MiuixTheme.textStyles.title4,
                        color = colorScheme.onSurface,
                    )
                    if (option.days == current) {
                        Icon(
                            imageVector = Icons.Rounded.CheckCircleOutline,
                            contentDescription = null,
                            tint = colorScheme.primary,
                            modifier = Modifier.size(20.dp),
                        )
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
        }
    }
}

/** Language picker rendered with Miuix, backed by EngineeringPageBridge. */
@Composable
private fun LanguageDialog(onClose: () -> Unit) {
    val colorScheme = MiuixTheme.colorScheme
    val context = androidx.compose.ui.platform.LocalContext.current
    var show by remember { mutableStateOf(true) }
    val options = remember {
        runCatching {
            com.smallhairball.deepx.EngineeringPageBridge.languageOptions()
        }.getOrDefault(emptyList())
    }
    val current = remember {
        runCatching {
            com.smallhairball.deepx.EngineeringPageBridge.currentLanguageMode(
                context as? android.app.Activity,
            )
        }.getOrDefault("auto")
    }

    OverlayDialog(
        title = "选择 DeePX 语言",
        show = show,
        onDismissRequest = { show = false },
        onDismissFinished = onClose,
    ) {
        options.forEach { option ->
            Card(
                onClick = {
                    runCatching {
                        com.smallhairball.deepx.EngineeringPageBridge.setLanguageMode(
                            context as? android.app.Activity, option.mode,
                        )
                    }
                    show = false
                },
                modifier = Modifier.fillMaxWidth(),
                showIndication = true,
                pressFeedbackType = PressFeedbackType.Sink,
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = option.title,
                            style = MiuixTheme.textStyles.title4,
                            color = colorScheme.onSurface,
                        )
                        if (option.description.isNotBlank()) {
                            Text(
                                text = option.description,
                                style = MiuixTheme.textStyles.footnote1,
                                color = colorScheme.onSurfaceVariantSummary,
                            )
                        }
                    }
                    if (option.mode == current) {
                        Icon(
                            imageVector = Icons.Rounded.CheckCircleOutline,
                            contentDescription = null,
                            tint = colorScheme.primary,
                            modifier = Modifier.size(20.dp),
                        )
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
        }
    }
}

/**
 * "Agent" settings page rendered with Miuix. Every control is delegated to
 * {@code AgentPageBridge}; the tool matrix is data-driven from {@code AgentToolConfig}.
 */
@Composable
private fun AgentPage(onBack: () -> Unit, onOpenRuns: () -> Unit, onOpenAdvanced: () -> Unit, onOpenMcp: () -> Unit) {
    val colorScheme = MiuixTheme.colorScheme
    val context = androidx.compose.ui.platform.LocalContext.current
    val scrollBehavior = MiuixScrollBehavior()
    val activity = context as? android.app.Activity

    val snapshot = remember {
        runCatching { com.smallhairball.deepx.AgentPageBridge.snapshot(activity) }.getOrNull()
    }
    var enabled by remember { mutableStateOf(snapshot?.enabled == true) }
    var promptStrength by remember { mutableStateOf(snapshot?.promptStrength ?: 1) }
    var backend by remember { mutableStateOf(snapshot?.backend ?: "in_app") }
    var backendDetail by remember { mutableStateOf(snapshot?.backendDetail ?: "") }
    var permission by remember { mutableStateOf(snapshot?.permission ?: "all") }
    val toolRows = remember {
        runCatching { com.smallhairball.deepx.AgentPageBridge.tools(activity) }
            .getOrDefault(emptyList())
    }
    val checkedMap = remember {
        androidx.compose.runtime.mutableStateMapOf<String, Boolean>().apply {
            toolRows.forEach { put(it.id, it.checked) }
        }
    }
    var showPermission by remember { mutableStateOf(false) }
    val promptLabel = when (promptStrength) {
        3 -> "第三档 · 沉浸"
        2 -> "第二档 · 增强"
        else -> "第一档 · 基础"
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = "Agent",
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                            contentDescription = "返回",
                            tint = colorScheme.onBackground,
                            modifier = Modifier.size(20.dp),
                        )
                    }
                },
                scrollBehavior = scrollBehavior,
            )
        },
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxHeight()
                .scrollEndHaptic()
                .overScrollVertical()
                .nestedScroll(scrollBehavior.nestedScrollConnection)
                .padding(horizontal = 12.dp),
            contentPadding = PaddingValues(
                top = innerPadding.calculateTopPadding() + 12.dp,
                bottom = innerPadding.calculateBottomPadding() + 24.dp,
            ),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            overscrollEffect = null,
        ) {
            item(key = "workspace") {
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.fillMaxWidth().padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "本地执行工作台",
                                    style = MiuixTheme.textStyles.title4,
                                    color = colorScheme.onSurface,
                                )
                                Spacer(Modifier.height(2.dp))
                                Text(
                                    text = "工具、权限与运行状态集中管理",
                                    style = MiuixTheme.textStyles.footnote1,
                                    color = colorScheme.onSurfaceVariantSummary,
                                )
                            }
                            Text(
                                text = if (enabled) "● 运行中" else "○ 已停用",
                                style = MiuixTheme.textStyles.footnote1,
                                color = if (enabled) colorScheme.primary else colorScheme.onSurfaceVariantSummary,
                            )
                        }
                        Spacer(Modifier.height(14.dp))
                        Row(modifier = Modifier.fillMaxWidth()) {
                            snapshot?.metrics?.forEachIndexed { index, metric ->
                                Column(
                                    modifier = Modifier.weight(1f),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                ) {
                                    Text(
                                        text = metric.label,
                                        style = MiuixTheme.textStyles.footnote1,
                                        color = colorScheme.onSurfaceVariantSummary,
                                    )
                                    Spacer(Modifier.height(2.dp))
                                    Text(
                                        text = if (index == 1) checkedMap.count { it.value }.toString() else metric.value,
                                        style = MiuixTheme.textStyles.title4,
                                        color = colorScheme.onSurface,
                                    )
                                }
                            }
                        }
                        if (!snapshot?.note.isNullOrBlank()) {
                            Spacer(Modifier.height(12.dp))
                            Text(
                                text = snapshot!!.note,
                                style = MiuixTheme.textStyles.footnote1,
                                color = colorScheme.onSurfaceVariantSummary,
                            )
                        }
                    }
                }
            }

            item(key = "enable") {
                Card(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "启用 Agent",
                                style = MiuixTheme.textStyles.title4,
                                color = colorScheme.onSurface,
                            )
                            Spacer(Modifier.height(2.dp))
                            Text(
                                text = "关闭后不会向模型提供本地工具，也不会执行工具控制块",
                                style = MiuixTheme.textStyles.footnote1,
                                color = colorScheme.onSurfaceVariantSummary,
                            )
                        }
                        Spacer(Modifier.width(12.dp))
                        Switch(
                            checked = enabled,
                            onCheckedChange = { value ->
                                val ok = runCatching {
                                    com.smallhairball.deepx.AgentPageBridge.setEnabled(activity, value)
                                }.getOrDefault(false)
                                if (ok) enabled = value
                            },
                        )
                    }
                }
            }

            item(key = "run_history") {
                Card(
                    onClick = onOpenRuns,
                    modifier = Modifier.fillMaxWidth(),
                    showIndication = true,
                    pressFeedbackType = PressFeedbackType.Sink,
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "运行记录",
                                style = MiuixTheme.textStyles.title4,
                                color = colorScheme.onSurface,
                            )
                            Spacer(Modifier.height(2.dp))
                            Text(
                                text = "查看状态，重试或取消尚未回传的结果",
                                style = MiuixTheme.textStyles.footnote1,
                                color = colorScheme.onSurfaceVariantSummary,
                            )
                        }
                        Icon(
                            imageVector = Icons.AutoMirrored.Rounded.KeyboardArrowRight,
                            contentDescription = null,
                            tint = colorScheme.onSurfaceVariantSummary,
                            modifier = Modifier.size(20.dp),
                        )
                    }
                }
            }

            item(key = "prompt_header") {
                Text(
                    text = "工具提示强度",
                    style = MiuixTheme.textStyles.footnote1,
                    color = colorScheme.onSurfaceVariantSummary,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                )
            }

            item(key = "prompt") {
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.fillMaxWidth().padding(16.dp)) {
                        Text(
                            text = promptLabel,
                            style = MiuixTheme.textStyles.title4,
                            color = colorScheme.onSurface,
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            text = snapshot?.promptDescription ?: "",
                            style = MiuixTheme.textStyles.footnote1,
                            color = colorScheme.onSurfaceVariantSummary,
                        )
                        Spacer(Modifier.height(8.dp))
                        Slider(
                            value = promptStrength.toFloat(),
                            onValueChange = { value ->
                                val level = value.toInt().coerceIn(1, 3)
                                if (level != promptStrength) {
                                    val ok = runCatching {
                                        com.smallhairball.deepx.AgentPageBridge.setPromptStrength(level)
                                    }.getOrDefault(false)
                                    if (ok) promptStrength = level
                                }
                            },
                            valueRange = 1f..3f,
                            steps = 1,
                            modifier = Modifier.fillMaxWidth(),
                        )
                        Row(modifier = Modifier.fillMaxWidth()) {
                            Text(
                                text = "基础",
                                modifier = Modifier.weight(1f),
                                style = MiuixTheme.textStyles.footnote1,
                                color = colorScheme.onSurfaceVariantSummary,
                            )
                            Text(
                                text = "增强",
                                modifier = Modifier.weight(1f),
                                style = MiuixTheme.textStyles.footnote1,
                                color = colorScheme.onSurfaceVariantSummary,
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                            )
                            Text(
                                text = "沉浸",
                                modifier = Modifier.weight(1f),
                                style = MiuixTheme.textStyles.footnote1,
                                color = colorScheme.onSurfaceVariantSummary,
                                textAlign = androidx.compose.ui.text.style.TextAlign.End,
                            )
                        }
                    }
                }
            }

            item(key = "backend_header") {
                Text(
                    text = "执行后端",
                    style = MiuixTheme.textStyles.footnote1,
                    color = colorScheme.onSurfaceVariantSummary,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                )
            }

            item(key = "backend") {
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.fillMaxWidth().padding(14.dp)) {
                        Text(
                            text = backendDetail,
                            style = MiuixTheme.textStyles.footnote1,
                            color = colorScheme.onSurfaceVariantSummary,
                        )
                        Spacer(Modifier.height(10.dp))
                        Row(modifier = Modifier.fillMaxWidth()) {
                            snapshot?.backends?.forEach { option ->
                                val selected = option.id == backend
                                Card(
                                    onClick = {
                                        backendDetail = "正在检测连接…"
                                        runCatching {
                                            com.smallhairball.deepx.AgentPageBridge.selectBackendSimple(
                                                activity, option.id,
                                                object : com.smallhairball.deepx.AgentPageBridge.BackendListener {
                                                    override fun onResult(connected: Boolean, detail: String) {
                                                        backendDetail = detail
                                                        if (connected) backend = option.id
                                                    }
                                                },
                                            )
                                        }
                                    },
                                    modifier = Modifier.weight(1f).padding(horizontal = 3.dp),
                                    showIndication = true,
                                    pressFeedbackType = PressFeedbackType.Sink,
                                    colors = if (selected) {
                                        CardDefaults.defaultColors(color = colorScheme.primary)
                                    } else {
                                        CardDefaults.defaultColors()
                                    },
                                ) {
                                    Text(
                                        text = option.label,
                                        modifier = Modifier.fillMaxWidth().padding(vertical = 10.dp),
                                        style = MiuixTheme.textStyles.body1,
                                        color = if (selected) colorScheme.onPrimary else colorScheme.onSurface,
                                        textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                                    )
                                }
                            }
                        }
                    }
                }
            }

            item(key = "permission") {
                Card(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "访问授权",
                                style = MiuixTheme.textStyles.title4,
                                color = colorScheme.onSurface,
                            )
                            Spacer(Modifier.height(2.dp))
                            Text(
                                text = snapshot?.permissionDescription ?: "",
                                style = MiuixTheme.textStyles.footnote1,
                                color = colorScheme.onSurfaceVariantSummary,
                            )
                        }
                        Spacer(Modifier.width(12.dp))
                        TextButton(
                            text = (snapshot?.permissionLabel ?: "全部允许") + " ▾",
                            onClick = { showPermission = true },
                        )
                    }
                }
            }

            item(key = "tools_header") {
                Text(
                    text = "工具",
                    style = MiuixTheme.textStyles.footnote1,
                    color = colorScheme.onSurfaceVariantSummary,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                )
            }

            items(toolRows.size, key = { toolRows[it].id }) { index ->
                val tool = toolRows[index]
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = tool.title,
                                    style = MiuixTheme.textStyles.title4,
                                    color = colorScheme.onSurface,
                                )
                                if (tool.subtitle.isNotBlank() && !tool.isMcp) {
                                    Spacer(Modifier.height(2.dp))
                                    Text(
                                        text = tool.subtitle,
                                        style = MiuixTheme.textStyles.footnote1,
                                        color = colorScheme.onSurfaceVariantSummary,
                                    )
                                }
                            }
                            Spacer(Modifier.width(12.dp))
                            Switch(
                                checked = checkedMap[tool.id] == true,
                                onCheckedChange = { value ->
                                    val ok = runCatching {
                                        com.smallhairball.deepx.AgentPageBridge.setToolEnabled(tool.id, value)
                                    }.getOrDefault(false)
                                    if (ok) checkedMap[tool.id] = value
                                },
                            )
                        }
                        if (tool.isMcp) {
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(start = 14.dp, end = 8.dp, bottom = 10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Text(
                                    text = tool.subtitle.substringBefore("    "),
                                    modifier = Modifier.weight(1f),
                                    style = MiuixTheme.textStyles.footnote1,
                                    color = colorScheme.onSurfaceVariantSummary,
                                )
                                TextButton(
                                    text = "MCP 设置 ›",
                                    onClick = onOpenMcp,
                                )
                            }
                        }
                    }
                }
            }

            item(key = "advanced") {
                Card(
                    onClick = onOpenAdvanced,
                    modifier = Modifier.fillMaxWidth(),
                    showIndication = true,
                    pressFeedbackType = PressFeedbackType.Sink,
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "高级选项",
                                style = MiuixTheme.textStyles.title4,
                                color = colorScheme.onSurface,
                            )
                            Spacer(Modifier.height(2.dp))
                            Text(
                                text = "显示、上下文与思考链默认行为",
                                style = MiuixTheme.textStyles.footnote1,
                                color = colorScheme.onSurfaceVariantSummary,
                            )
                        }
                        Icon(
                            imageVector = Icons.AutoMirrored.Rounded.KeyboardArrowRight,
                            contentDescription = null,
                            tint = colorScheme.onSurfaceVariantSummary,
                            modifier = Modifier.size(20.dp),
                        )
                    }
                }
            }
        }
    }

    if (showPermission) {
        AgentPermissionDialog(
            activity = activity,
            current = permission,
            onClose = { showPermission = false },
            onSelected = { value ->
                val ok = runCatching {
                    com.smallhairball.deepx.AgentPageBridge.setPermission(value)
                }.getOrDefault(false)
                if (ok) permission = value
            },
        )
    }
}

/** Access-permission picker for the Agent page. */
@Composable
private fun AgentPermissionDialog(
    activity: android.app.Activity?,
    current: String,
    onClose: () -> Unit,
    onSelected: (String) -> Unit,
) {
    val colorScheme = MiuixTheme.colorScheme
    val options = remember {
        runCatching { com.smallhairball.deepx.AgentPageBridge.permissionOptions(activity) }
            .getOrDefault(emptyList())
    }
    var show by remember { mutableStateOf(true) }
    var pending by remember { mutableStateOf<String?>(null) }

    OverlayDialog(
        title = "访问授权",
        show = show,
        onDismissRequest = { show = false },
        onDismissFinished = {
            val value = pending
            if (value != null) onSelected(value) else onClose()
        },
    ) {
        options.forEach { option ->
            Card(
                onClick = { pending = option.id; show = false },
                modifier = Modifier.fillMaxWidth(),
                showIndication = true,
                pressFeedbackType = PressFeedbackType.Sink,
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        text = option.label,
                        modifier = Modifier.weight(1f),
                        style = MiuixTheme.textStyles.title4,
                        color = colorScheme.onSurface,
                    )
                    if (option.id == current) {
                        Icon(
                            imageVector = Icons.Rounded.CheckCircleOutline,
                            contentDescription = null,
                            tint = colorScheme.primary,
                            modifier = Modifier.size(20.dp),
                        )
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
        }
    }
}

/**
 * "Agent runs" history page rendered with Miuix. Snapshot and actions are delegated to
 * {@code AgentPageBridge}.
 */
@Composable
private fun AgentRunsPage(onBack: () -> Unit) {
    val colorScheme = MiuixTheme.colorScheme
    val context = androidx.compose.ui.platform.LocalContext.current
    val scrollBehavior = MiuixScrollBehavior()
    val activity = context as? android.app.Activity

    var refreshTick by remember { mutableStateOf(0) }
    var pendingCancel by remember { mutableStateOf<String?>(null) }
    val summary = remember(refreshTick) {
        runCatching { com.smallhairball.deepx.AgentPageBridge.runSummary(activity) }.getOrNull()
    }
    val rows = summary?.rows ?: emptyList()

    Scaffold(
        topBar = {
            TopAppBar(
                title = "Agent 运行记录",
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                            contentDescription = "返回",
                            tint = colorScheme.onBackground,
                            modifier = Modifier.size(20.dp),
                        )
                    }
                },
                scrollBehavior = scrollBehavior,
            )
        },
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxHeight()
                .scrollEndHaptic()
                .overScrollVertical()
                .nestedScroll(scrollBehavior.nestedScrollConnection)
                .padding(horizontal = 12.dp),
            contentPadding = PaddingValues(
                top = innerPadding.calculateTopPadding() + 12.dp,
                bottom = innerPadding.calculateBottomPadding() + 24.dp,
            ),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            overscrollEffect = null,
        ) {
            item(key = "summary") {
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.fillMaxWidth().padding(15.dp)) {
                        Text(
                            text = summary?.headline ?: "",
                            style = MiuixTheme.textStyles.title4,
                            color = colorScheme.onSurface,
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            text = summary?.explanation ?: "",
                            style = MiuixTheme.textStyles.footnote1,
                            color = colorScheme.onSurfaceVariantSummary,
                        )
                        Spacer(Modifier.height(12.dp))
                        Row(modifier = Modifier.fillMaxWidth()) {
                            val pending = summary?.pending ?: 0
                            val finished = summary?.finished ?: 0
                            TextButton(
                                text = "刷新",
                                onClick = {
                                    runCatching {
                                        com.smallhairball.deepx.AgentPageBridge.resumeOutbox(activity)
                                    }
                                    refreshTick++
                                },
                                modifier = Modifier.weight(1f),
                            )
                            Spacer(Modifier.width(12.dp))
                            TextButton(
                                text = "重试待回传",
                                onClick = {
                                    runCatching {
                                        com.smallhairball.deepx.AgentPageBridge.retryAllPending(activity)
                                    }
                                    refreshTick++
                                },
                                enabled = pending > 0,
                                modifier = Modifier.weight(1f),
                            )
                            Spacer(Modifier.width(12.dp))
                            TextButton(
                                text = "清除已结束",
                                onClick = {
                                    runCatching {
                                        com.smallhairball.deepx.AgentPageBridge.clearFinishedRuns()
                                    }
                                    refreshTick++
                                },
                                enabled = finished > 0,
                                modifier = Modifier.weight(1f),
                            )
                        }
                    }
                }
            }

            if (rows.isEmpty()) {
                item(key = "empty") {
                    Text(
                        text = "还没有 Agent 工具运行记录",
                        modifier = Modifier.fillMaxWidth().padding(vertical = 48.dp),
                        style = MiuixTheme.textStyles.body1,
                        color = colorScheme.onSurfaceVariantSummary,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                    )
                }
            } else {
                items(rows.size, key = { rows[it].outboxId.ifEmpty { "run_" + it } }) { index ->
                    val row = rows[index]
                    val stateColor = when (row.stateKind) {
                        "error" -> colorScheme.error
                        "done" -> colorScheme.primary
                        else -> colorScheme.primary
                    }
                    Card(modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.fillMaxWidth().padding(15.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = row.title,
                                    modifier = Modifier.weight(1f),
                                    style = MiuixTheme.textStyles.title4,
                                    color = colorScheme.onSurface,
                                )
                                Text(
                                    text = row.state,
                                    style = MiuixTheme.textStyles.footnote1,
                                    color = stateColor,
                                )
                            }
                            Spacer(Modifier.height(4.dp))
                            Text(
                                text = row.metadata,
                                style = MiuixTheme.textStyles.footnote1,
                                color = colorScheme.onSurfaceVariantSummary,
                            )
                            if (row.detail.isNotBlank()) {
                                Spacer(Modifier.height(6.dp))
                                Text(
                                    text = row.detail,
                                    style = MiuixTheme.textStyles.footnote1,
                                    color = colorScheme.onSurfaceVariantSummary,
                                )
                            }
                            if (row.pending) {
                                Spacer(Modifier.height(12.dp))
                                Row(modifier = Modifier.fillMaxWidth()) {
                                    TextButton(
                                        text = "立即重试",
                                        onClick = {
                                            runCatching {
                                                com.smallhairball.deepx.AgentPageBridge.retryRun(
                                                    activity, row.outboxId,
                                                )
                                            }
                                            refreshTick++
                                        },
                                        modifier = Modifier.weight(1f),
                                    )
                                    Spacer(Modifier.width(12.dp))
                                    TextButton(
                                        text = "取消回传",
                                        onClick = {
                                            pendingCancel = row.outboxId
                                        },
                                        modifier = Modifier.weight(1f),
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    val cancelId = pendingCancel
    if (cancelId != null) {
        ConfirmDialog(
            title = "取消这条结果回传？",
            message = remember {
                runCatching {
                    com.smallhairball.deepx.AgentPageBridge.cancelRunMessage(context)
                }.getOrDefault("")
            },
            negativeLabel = "返回",
            positiveLabel = "取消回传",
            onNegative = { pendingCancel = null },
            onPositive = {
                pendingCancel = null
                runCatching { com.smallhairball.deepx.AgentPageBridge.cancelRun(cancelId) }
                refreshTick++
            },
            verticalButtons = false,
            onDismissDialog = { pendingCancel = null },
        )
    }
}

/**
 * "Agent advanced options" page rendered with Miuix. The switch matrix is delegated to
 * {@code AgentPageBridge}.
 */
@Composable
private fun AgentAdvancedPage(onBack: () -> Unit) {
    val colorScheme = MiuixTheme.colorScheme
    val context = androidx.compose.ui.platform.LocalContext.current
    val scrollBehavior = MiuixScrollBehavior()
    val activity = context as? android.app.Activity

    val rows = remember {
        runCatching { com.smallhairball.deepx.AgentPageBridge.advancedRows(activity) }
            .getOrDefault(emptyList())
    }
    val checkedMap = remember {
        androidx.compose.runtime.mutableStateMapOf<String, Boolean>().apply {
            rows.forEach { put(it.id, it.checked) }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = "高级选项",
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                            contentDescription = "返回",
                            tint = colorScheme.onBackground,
                            modifier = Modifier.size(20.dp),
                        )
                    }
                },
                scrollBehavior = scrollBehavior,
            )
        },
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxHeight()
                .scrollEndHaptic()
                .overScrollVertical()
                .nestedScroll(scrollBehavior.nestedScrollConnection)
                .padding(horizontal = 12.dp),
            contentPadding = PaddingValues(
                top = innerPadding.calculateTopPadding() + 12.dp,
                bottom = innerPadding.calculateBottomPadding() + 24.dp,
            ),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            overscrollEffect = null,
        ) {
            items(rows.size, key = { rows[it].id }) { index ->
                val row = rows[index]
                Card(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = row.title,
                                style = MiuixTheme.textStyles.title4,
                                color = colorScheme.onSurface,
                            )
                            if (row.subtitle.isNotBlank()) {
                                Spacer(Modifier.height(2.dp))
                                Text(
                                    text = row.subtitle,
                                    style = MiuixTheme.textStyles.footnote1,
                                    color = colorScheme.onSurfaceVariantSummary,
                                )
                            }
                        }
                        Spacer(Modifier.width(12.dp))
                        Switch(
                            checked = checkedMap[row.id] == true,
                            onCheckedChange = { value ->
                                val ok = runCatching {
                                    com.smallhairball.deepx.AgentPageBridge.setAdvanced(
                                        activity, row.id, value,
                                    )
                                }.getOrDefault(false)
                                if (ok) checkedMap[row.id] = value
                            },
                        )
                    }
                }
            }
        }
    }
}

/**
 * "MCP tools" page rendered with Miuix. The server list and editor payload are delegated to
 * {@code McpPageBridge}.
 */
@Composable
private fun McpPage(onBack: () -> Unit) {
    val colorScheme = MiuixTheme.colorScheme
    val context = androidx.compose.ui.platform.LocalContext.current
    val scrollBehavior = MiuixScrollBehavior()
    val activity = context as? android.app.Activity

    var refreshTick by remember { mutableStateOf(0) }
    var editorIndex by remember { mutableStateOf<Int?>(null) }
    var editorOpen by remember { mutableStateOf(false) }
    val servers = remember(refreshTick) {
        runCatching { com.smallhairball.deepx.McpPageBridge.servers(activity) }
            .getOrDefault(emptyList())
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = "MCP 工具",
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                            contentDescription = "返回",
                            tint = colorScheme.onBackground,
                            modifier = Modifier.size(20.dp),
                        )
                    }
                },
                actions = {
                    IconButton(onClick = {
                        editorIndex = null
                        editorOpen = true
                    }) {
                        Icon(
                            imageVector = Icons.Rounded.Build,
                            contentDescription = "添加 MCP 服务",
                            tint = colorScheme.onBackground,
                            modifier = Modifier.size(20.dp),
                        )
                    }
                },
                scrollBehavior = scrollBehavior,
            )
        },
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxHeight()
                .scrollEndHaptic()
                .overScrollVertical()
                .nestedScroll(scrollBehavior.nestedScrollConnection)
                .padding(horizontal = 12.dp),
            contentPadding = PaddingValues(
                top = innerPadding.calculateTopPadding() + 12.dp,
                bottom = innerPadding.calculateBottomPadding() + 24.dp,
            ),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            overscrollEffect = null,
        ) {
            item(key = "intro") {
                Text(
                    text = runCatching {
                        com.smallhairball.deepx.McpPageBridge.listIntro(activity, servers.isEmpty())
                    }.getOrDefault(""),
                    style = MiuixTheme.textStyles.footnote1,
                    color = colorScheme.onSurfaceVariantSummary,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                )
            }

            if (servers.isEmpty()) {
                item(key = "empty") {
                    Card(modifier = Modifier.fillMaxWidth()) {
                        Text(
                            text = runCatching {
                                com.smallhairball.deepx.McpPageBridge.emptyHint(context)
                            }.getOrDefault(""),
                            modifier = Modifier.fillMaxWidth().padding(22.dp),
                            style = MiuixTheme.textStyles.body2,
                            color = colorScheme.onSurfaceVariantSummary,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                        )
                    }
                }
            } else {
                items(servers.size, key = { servers[it].index }) { index ->
                    val server = servers[index]
                    val statusColor = when (server.statusKind) {
                        "online" -> colorScheme.primary
                        else -> colorScheme.onSurfaceVariantSummary
                    }
                    Card(
                        onClick = {
                            editorIndex = server.index
                            editorOpen = true
                        },
                        modifier = Modifier.fillMaxWidth(),
                        showIndication = true,
                        pressFeedbackType = PressFeedbackType.Sink,
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(15.dp),
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = server.name,
                                        style = MiuixTheme.textStyles.title4,
                                        color = colorScheme.onSurface,
                                    )
                                    Spacer(Modifier.height(2.dp))
                                    Text(
                                        text = server.endpoint,
                                        style = MiuixTheme.textStyles.footnote1,
                                        color = colorScheme.onSurfaceVariantSummary,
                                        maxLines = 1,
                                    )
                                }
                                Spacer(Modifier.width(12.dp))
                                Switch(
                                    checked = server.enabled,
                                    onCheckedChange = { value ->
                                        val ok = runCatching {
                                            com.smallhairball.deepx.McpPageBridge.setEnabled(
                                                activity, server.index, value,
                                            )
                                        }.getOrDefault(false)
                                        if (ok) {
                                            if (value) {
                                                runCatching {
                                                    com.smallhairball.deepx.McpPageBridge.probeAll(
                                                        activity, null,
                                                    )
                                                }
                                            }
                                            refreshTick++
                                        }
                                    },
                                )
                            }
                            Spacer(Modifier.height(8.dp))
                            Text(
                                text = server.statusLine,
                                style = MiuixTheme.textStyles.footnote1,
                                color = statusColor,
                            )
                        }
                    }
                }
            }
        }
    }

    if (editorOpen) {
        McpEditorDialog(
            index = editorIndex,
            onClose = { editorOpen = false },
            onSaved = {
                editorOpen = false
                refreshTick++
            },
        )
    }
}

/**
 * MCP server editor rendered with Miuix: name, endpoint, transport and custom request headers,
 * delegated to {@code McpPageBridge}.
 */
@Composable
private fun McpEditorDialog(index: Int?, onClose: () -> Unit, onSaved: () -> Unit) {
    val colorScheme = MiuixTheme.colorScheme
    val context = androidx.compose.ui.platform.LocalContext.current
    val activity = context as? android.app.Activity

    val editor = remember(index) {
        runCatching { com.smallhairball.deepx.McpPageBridge.editor(activity, index) }.getOrNull()
    }
    val nameState = androidx.compose.foundation.text.input.rememberTextFieldState(
        editor?.name ?: "",
    )
    val urlState = androidx.compose.foundation.text.input.rememberTextFieldState(
        editor?.url ?: "",
    )
    var enabled by remember { mutableStateOf(editor?.enabled == true) }
    var transport by remember { mutableStateOf(editor?.transport ?: "streamable_http") }
    val headers = remember(index) {
        androidx.compose.runtime.mutableStateListOf<McpHeaderEntry>().apply {
            editor?.headers?.forEach { add(McpHeaderEntry(it.name, it.value)) }
        }
    }
    val transportOptions = remember {
        runCatching { com.smallhairball.deepx.McpPageBridge.transports(context) }
            .getOrDefault(emptyList())
    }
    var showTransport by remember { mutableStateOf(false) }
    var showDelete by remember { mutableStateOf(false) }
    var show by remember { mutableStateOf(true) }
    var saved by remember { mutableStateOf(false) }

    OverlayDialog(
        title = if (index == null) "添加 MCP 服务" else "编辑 MCP 服务",
        show = show,
        onDismissRequest = { show = false },
        onDismissFinished = {
            if (saved) onSaved() else onClose()
        },
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = if (editor?.enabled != false) "" else "",
                style = MiuixTheme.textStyles.footnote1,
                color = colorScheme.onSurfaceVariantSummary,
            )
            Spacer(Modifier.weight(1f))
            Text(
                text = "启用",
                style = MiuixTheme.textStyles.footnote1,
                color = colorScheme.onSurfaceVariantSummary,
            )
            Spacer(Modifier.width(8.dp))
            Switch(checked = enabled, onCheckedChange = { enabled = it })
        }
        Spacer(Modifier.height(12.dp))
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(max = 420.dp)
                .verticalScroll(rememberScrollState()),
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                TextField(state = nameState, label = "服务名称")
                Spacer(Modifier.height(10.dp))
                TextField(state = urlState, label = "Streamable HTTP / SSE 地址")
                Spacer(Modifier.height(10.dp))
                Card(
                    onClick = { showTransport = true },
                    modifier = Modifier.fillMaxWidth(),
                    showIndication = true,
                    pressFeedbackType = PressFeedbackType.Sink,
                ) {
                    Text(
                        text = "传输方式　" + (transportOptions.firstOrNull { it.name == transport }?.value ?: "Streamable HTTP"),
                        modifier = Modifier.fillMaxWidth().padding(14.dp),
                        style = MiuixTheme.textStyles.body1,
                        color = colorScheme.onSurface,
                    )
                }
                Spacer(Modifier.height(14.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "自定义请求头",
                        modifier = Modifier.weight(1f),
                        style = MiuixTheme.textStyles.title4,
                        color = colorScheme.onSurface,
                    )
                    TextButton(text = "＋ 添加", onClick = { headers.add(McpHeaderEntry("", "")) })
                }
                headers.forEachIndexed { headerIndex, entry ->
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Box(modifier = Modifier.weight(0.42f)) {
                            TextField(state = entry.name, label = "请求头")
                        }
                        Spacer(Modifier.width(7.dp))
                        Box(modifier = Modifier.weight(0.52f)) {
                            TextField(state = entry.value, label = "请求值")
                        }
                        Spacer(Modifier.width(2.dp))
                        IconButton(onClick = { if (headerIndex < headers.size) headers.removeAt(headerIndex) }) {
                            Icon(
                                imageVector = Icons.Rounded.BlurOn,
                                contentDescription = "删除请求头",
                                tint = colorScheme.onSurfaceVariantSummary,
                                modifier = Modifier.size(18.dp),
                            )
                        }
                    }
                }
                if (!headers.isEmpty()) {
                    Spacer(Modifier.height(6.dp))
                    Text(
                        text = runCatching {
                            com.smallhairball.deepx.McpPageBridge.headerHint(context)
                        }.getOrDefault(""),
                        style = MiuixTheme.textStyles.footnote1,
                        color = colorScheme.onSurfaceVariantSummary,
                    )
                }
            }
        }
        Spacer(Modifier.height(14.dp))
        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            if (index != null) {
                TextButton(
                    text = "删除",
                    onClick = { showDelete = true },
                )
                Spacer(Modifier.weight(1f))
            }
            TextButton(text = "取消", onClick = { show = false })
            Spacer(Modifier.width(9.dp))
            TextButton(
                text = "保存并检测",
                onClick = {
                    val stored = headers.map { entry ->
                        com.smallhairball.deepx.McpPageBridge.Header(
                            entry.name.text.toString(), entry.value.text.toString(),
                        )
                    }
                    val ok = runCatching {
                        com.smallhairball.deepx.McpPageBridge.save(
                            activity, index, enabled,
                            nameState.text.toString(), urlState.text.toString(), transport, stored,
                        )
                    }.getOrDefault(false)
                    if (!ok) return@TextButton
                    if (enabled) {
                        com.smallhairball.deepx.McpPageBridge.probeAll(activity, null)
                    }
                    saved = true
                    show = false
                },
                colors = ButtonDefaults.textButtonColorsPrimary(),
            )
        }
    }

    if (showTransport) {
        val options = transportOptions
        var transportShow by remember { mutableStateOf(true) }
        var pendingTransport by remember { mutableStateOf<String?>(null) }
        OverlayDialog(
            title = "传输方式",
            show = transportShow,
            onDismissRequest = { transportShow = false },
            onDismissFinished = {
                val value = pendingTransport
                if (value != null) transport = value
                showTransport = false
            },
        ) {
            options.forEach { option ->
                Card(
                    onClick = { pendingTransport = option.name; transportShow = false },
                    modifier = Modifier.fillMaxWidth(),
                    showIndication = true,
                    pressFeedbackType = PressFeedbackType.Sink,
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(
                            text = option.value,
                            modifier = Modifier.weight(1f),
                            style = MiuixTheme.textStyles.title4,
                            color = colorScheme.onSurface,
                        )
                        if (option.name == transport) {
                            Icon(
                                imageVector = Icons.Rounded.CheckCircleOutline,
                                contentDescription = null,
                                tint = colorScheme.primary,
                                modifier = Modifier.size(20.dp),
                            )
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
            }
        }
    }

    if (showDelete && index != null) {
        ConfirmDialog(
            title = "删除这个 MCP 服务？",
            message = "服务配置与已同步的工具都会移除。",
            negativeLabel = "取消",
            positiveLabel = "删除",
            onNegative = { showDelete = false },
            onPositive = {
                showDelete = false
                runCatching { com.smallhairball.deepx.McpPageBridge.remove(activity, index) }
                saved = true
                show = false
            },
            verticalButtons = false,
            onDismissDialog = { showDelete = false },
        )
    }
}

/** One editable custom request header with its own text-field states. */
private class McpHeaderEntry(name: String, value: String) {
    val name = androidx.compose.foundation.text.input.TextFieldState(name)
    val value = androidx.compose.foundation.text.input.TextFieldState(value)
}

/**
 * "Java plugin" page rendered with Miuix. The plugin list and learning entries are delegated to
 * {@code JavaPluginPageBridge}.
 */
@Composable
private fun JavaPluginPage(onBack: () -> Unit, onOpenHooks: () -> Unit) {
    val colorScheme = MiuixTheme.colorScheme
    val context = androidx.compose.ui.platform.LocalContext.current
    val scrollBehavior = MiuixScrollBehavior()
    val activity = context as? android.app.Activity

    var refreshTick by remember { mutableStateOf(0) }
    var showImport by remember { mutableStateOf(false) }
    var textTitle by remember { mutableStateOf("") }
    var textBody by remember { mutableStateOf("") }
    var toast by remember { mutableStateOf("") }
    var removing by remember { mutableStateOf<com.smallhairball.deepx.JavaPluginPageBridge.Plugin?>(null) }
    val summary = remember(refreshTick) {
        runCatching { com.smallhairball.deepx.JavaPluginPageBridge.summary(activity) }.getOrNull()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = "Java 插件",
                subtitle = "正式版 · ABI v3",
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                            contentDescription = "返回",
                            tint = colorScheme.onBackground,
                            modifier = Modifier.size(20.dp),
                        )
                    }
                },
                actions = {
                    TextButton(text = "Hook 点", onClick = onOpenHooks)
                    Spacer(Modifier.width(6.dp))
                    TextButton(text = "导入", onClick = { showImport = true })
                },
                scrollBehavior = scrollBehavior,
            )
        },
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxHeight()
                .scrollEndHaptic()
                .overScrollVertical()
                .nestedScroll(scrollBehavior.nestedScrollConnection)
                .padding(horizontal = 12.dp),
            contentPadding = PaddingValues(
                top = innerPadding.calculateTopPadding() + 12.dp,
                bottom = innerPadding.calculateBottomPadding() + 24.dp,
            ),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            overscrollEffect = null,
        ) {
            item(key = "summary") {
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.fillMaxWidth().padding(16.dp)) {
                        Text(
                            text = summary?.title ?: "",
                            style = MiuixTheme.textStyles.title4,
                            color = colorScheme.onSurface,
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            text = summary?.stats ?: "",
                            style = MiuixTheme.textStyles.footnote1,
                            color = colorScheme.primary,
                        )
                        Spacer(Modifier.height(10.dp))
                        Text(
                            text = summary?.warning ?: "",
                            style = MiuixTheme.textStyles.footnote1,
                            color = colorScheme.onSurfaceVariantSummary,
                        )
                    }
                }
            }

            item(key = "installed_header") {
                Text(
                    text = "已安装",
                    style = MiuixTheme.textStyles.footnote1,
                    color = colorScheme.onSurfaceVariantSummary,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                )
            }

            items(summary?.plugins?.size ?: 0, key = { summary!!.plugins[it].id }) { index ->
                val plugin = summary!!.plugins[index]
                val statusColor = when (plugin.statusKind) {
                    "error" -> colorScheme.error
                    "good" -> colorScheme.primary
                    else -> colorScheme.onSurfaceVariantSummary
                }
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.fillMaxWidth().padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = plugin.name,
                                    style = MiuixTheme.textStyles.title4,
                                    color = colorScheme.onSurface,
                                )
                                Spacer(Modifier.height(2.dp))
                                Text(
                                    text = plugin.versionAuthor,
                                    style = MiuixTheme.textStyles.footnote1,
                                    color = colorScheme.onSurfaceVariantSummary,
                                )
                            }
                            if (!plugin.builtIn) {
                                Spacer(Modifier.width(12.dp))
                                Switch(
                                    checked = plugin.enabled,
                                    onCheckedChange = { value ->
                                        val ok = runCatching {
                                            com.smallhairball.deepx.JavaPluginPageBridge.setEnabled(
                                                activity, plugin.id, value,
                                            )
                                        }.getOrDefault(false)
                                        if (ok) refreshTick++ else toast = "插件状态保存失败"
                                    },
                                )
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                        Text(
                            text = plugin.description,
                            style = MiuixTheme.textStyles.footnote1,
                            color = colorScheme.onSurfaceVariantSummary,
                        )
                        Spacer(Modifier.height(10.dp))
                        Text(
                            text = plugin.status,
                            style = MiuixTheme.textStyles.footnote1,
                            color = statusColor,
                        )
                        Spacer(Modifier.height(12.dp))
                        if (plugin.builtIn) {
                            TextButton(
                                text = "一键测试",
                                onClick = {
                                    com.smallhairball.deepx.JavaPluginPageBridge.runBuiltInTest(
                                        activity,
                                        object : com.smallhairball.deepx.JavaPluginPageBridge.TestListener {
                                            override fun onDone(success: Boolean, message: String) {
                                                toast = message
                                            }
                                        },
                                    )
                                },
                                modifier = Modifier.fillMaxWidth(),
                                colors = ButtonDefaults.textButtonColorsPrimary(),
                            )
                        } else {
                            Row(modifier = Modifier.fillMaxWidth()) {
                                TextButton(
                                    text = "查看清单",
                                    onClick = {
                                        textTitle = plugin.name
                                        textBody = runCatching {
                                            com.smallhairball.deepx.JavaPluginPageBridge.manifest(
                                                activity, plugin.id,
                                            )
                                        }.getOrDefault("")
                                    },
                                    modifier = Modifier.weight(1f),
                                )
                                Spacer(Modifier.width(12.dp))
                                TextButton(
                                    text = "删除",
                                    onClick = { removing = plugin },
                                    modifier = Modifier.weight(1f),
                                )
                            }
                        }
                    }
                }
            }

            item(key = "learning_header") {
                Text(
                    text = "学习与开发",
                    style = MiuixTheme.textStyles.footnote1,
                    color = colorScheme.onSurfaceVariantSummary,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                )
            }

            items(summary?.links?.size ?: 0, key = { summary!!.links[it].id }) { index ->
                val link = summary!!.links[index]
                Card(
                    onClick = {
                        when (link.id) {
                            "tutorial" -> {
                                textTitle = "Java 插件使用教程"
                                textBody = runCatching {
                                    com.smallhairball.deepx.JavaPluginPageBridge.tutorialText()
                                }.getOrDefault("")
                            }
                            "ai_reference" -> runCatching {
                                com.smallhairball.deepx.JavaPluginPageBridge.exportAiReference(activity)
                            }
                            "tutorial_zip" -> runCatching {
                                com.smallhairball.deepx.JavaPluginPageBridge.exportTutorial(activity)
                            }
                            "hook_catalog" -> onOpenHooks()
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    showIndication = true,
                    pressFeedbackType = PressFeedbackType.Sink,
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = link.title,
                                style = MiuixTheme.textStyles.title4,
                                color = colorScheme.onSurface,
                            )
                            Spacer(Modifier.height(2.dp))
                            Text(
                                text = link.subtitle,
                                style = MiuixTheme.textStyles.footnote1,
                                color = colorScheme.onSurfaceVariantSummary,
                            )
                        }
                        Icon(
                            imageVector = Icons.AutoMirrored.Rounded.KeyboardArrowRight,
                            contentDescription = null,
                            tint = colorScheme.onSurfaceVariantSummary,
                            modifier = Modifier.size(20.dp),
                        )
                    }
                }
            }
        }
    }

    if (showImport) {
        ConfirmDialog(
            title = "导入 Java 插件",
            message = remember {
                runCatching {
                    com.smallhairball.deepx.JavaPluginPageBridge.importWarning(context)
                }.getOrDefault("")
            },
            negativeLabel = "取消",
            positiveLabel = "选择 ZIP",
            onNegative = { showImport = false },
            onPositive = {
                showImport = false
                runCatching { com.smallhairball.deepx.JavaPluginPageBridge.pickImport(activity) }
            },
            verticalButtons = true,
            onDismissDialog = { showImport = false },
        )
    }

    val pendingRemove = removing
    if (pendingRemove != null) {
        ConfirmDialog(
            title = "删除 " + pendingRemove.name + "？",
            message = "将删除插件代码、优化缓存和清单。此操作无法撤销。",
            negativeLabel = "取消",
            positiveLabel = "删除",
            onNegative = { removing = null },
            onPositive = {
                removing = null
                runCatching {
                    com.smallhairball.deepx.JavaPluginPageBridge.remove(activity, pendingRemove.id)
                }
                refreshTick++
            },
            verticalButtons = false,
            onDismissDialog = { removing = null },
        )
    }

    if (textBody.isNotBlank() || textTitle.isNotBlank()) {
        val scheme = MiuixTheme.colorScheme
        var textShow by remember(textTitle) { mutableStateOf(true) }
        OverlayDialog(
            title = textTitle,
            show = textShow,
            onDismissRequest = { textShow = false },
            onDismissFinished = { textTitle = ""; textBody = "" },
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 420.dp)
                    .verticalScroll(rememberScrollState()),
            ) {
                Text(
                    text = textBody,
                    style = MiuixTheme.textStyles.footnote1,
                    color = scheme.onSurfaceVariantSummary,
                )
            }
            Spacer(Modifier.height(12.dp))
            TextButton(
                text = "完成",
                onClick = { textShow = false },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.textButtonColorsPrimary(),
            )
        }
    }

    if (toast.isNotBlank()) {
        val scheme = MiuixTheme.colorScheme
        var toastShow by remember { mutableStateOf(true) }
        OverlayDialog(
            title = "提示",
            show = toastShow,
            onDismissRequest = { toastShow = false },
            onDismissFinished = { toast = "" },
        ) {
            Text(
                text = toast,
                style = MiuixTheme.textStyles.body2,
                color = scheme.onSurface,
            )
            Spacer(Modifier.height(12.dp))
            TextButton(
                text = "知道了",
                onClick = { toastShow = false },
                modifier = Modifier.fillMaxWidth(),
            )
        }
    }
}

/**
 * "Hook catalogue" page rendered with Miuix: a flat, grouped list of hook points delegated to
 * {@code JavaPluginPageBridge}.
 */
@Composable
private fun HookCatalogPage(onBack: () -> Unit) {
    val colorScheme = MiuixTheme.colorScheme
    val context = androidx.compose.ui.platform.LocalContext.current
    val scrollBehavior = MiuixScrollBehavior()
    val activity = context as? android.app.Activity

    val stats = remember {
        runCatching { com.smallhairball.deepx.JavaPluginPageBridge.hookStats(activity) }
            .getOrDefault("")
    }
    val note = remember {
        runCatching { com.smallhairball.deepx.JavaPluginPageBridge.hookNote(activity) }
            .getOrDefault("")
    }
    val hooks = remember {
        runCatching { com.smallhairball.deepx.JavaPluginPageBridge.hooks() }
            .getOrDefault(emptyList())
    }
    val grouped = remember(hooks) { hooks.groupBy { it.category } }
    var detailTitle by remember { mutableStateOf("") }
    var detailBody by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = "Hook 点目录",
                subtitle = stats,
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                            contentDescription = "返回",
                            tint = colorScheme.onBackground,
                            modifier = Modifier.size(20.dp),
                        )
                    }
                },
                scrollBehavior = scrollBehavior,
            )
        },
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxHeight()
                .scrollEndHaptic()
                .overScrollVertical()
                .nestedScroll(scrollBehavior.nestedScrollConnection)
                .padding(horizontal = 12.dp),
            contentPadding = PaddingValues(
                top = innerPadding.calculateTopPadding() + 12.dp,
                bottom = innerPadding.calculateBottomPadding() + 24.dp,
            ),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            overscrollEffect = null,
        ) {
            item(key = "note") {
                Text(
                    text = note,
                    style = MiuixTheme.textStyles.footnote1,
                    color = colorScheme.onSurfaceVariantSummary,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                )
            }
            grouped.forEach { (category, points) ->
                item(key = "cat_" + category) {
                    Text(
                        text = category,
                        style = MiuixTheme.textStyles.footnote1,
                        color = colorScheme.onSurfaceVariantSummary,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                    )
                }
                items(points.size, key = { points[it].id }) { index ->
                    val point = points[index]
                    Card(
                        onClick = {
                            detailTitle = point.title
                            detailBody = runCatching {
                                com.smallhairball.deepx.JavaPluginPageBridge.hookDetail(point.id)
                            }.getOrDefault("")
                        },
                        modifier = Modifier.fillMaxWidth(),
                        showIndication = true,
                        pressFeedbackType = PressFeedbackType.Sink,
                    ) {
                        Column(modifier = Modifier.fillMaxWidth().padding(14.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = point.title,
                                    modifier = Modifier.weight(1f),
                                    style = MiuixTheme.textStyles.title4,
                                    color = colorScheme.onSurface,
                                )
                                Text(
                                    text = if (point.wired) "已接线" else "未接线",
                                    style = MiuixTheme.textStyles.footnote1,
                                    color = if (point.wired) colorScheme.primary
                                    else colorScheme.onSurfaceVariantSummary,
                                )
                            }
                            if (point.detail.isNotBlank()) {
                                Spacer(Modifier.height(2.dp))
                                Text(
                                    text = point.detail,
                                    style = MiuixTheme.textStyles.footnote1,
                                    color = colorScheme.onSurfaceVariantSummary,
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    if (detailBody.isNotBlank() || detailTitle.isNotBlank()) {
        val scheme = MiuixTheme.colorScheme
        var detailShow by remember(detailTitle) { mutableStateOf(true) }
        OverlayDialog(
            title = detailTitle,
            show = detailShow,
            onDismissRequest = { detailShow = false },
            onDismissFinished = { detailTitle = ""; detailBody = "" },
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 420.dp)
                    .verticalScroll(rememberScrollState()),
            ) {
                Text(
                    text = detailBody,
                    style = MiuixTheme.textStyles.footnote1,
                    color = scheme.onSurfaceVariantSummary,
                )
            }
            Spacer(Modifier.height(12.dp))
            TextButton(
                text = "完成",
                onClick = { detailShow = false },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.textButtonColorsPrimary(),
            )
        }
    }
}

/**
 * "Process manager" page rendered with Miuix. Root-backed logic stays in
 * {@code ProcessManagerActivity}; this only renders the list and action sheet.
 */
@Composable
private fun ProcessManagerPage(onBack: () -> Unit) {
    val colorScheme = MiuixTheme.colorScheme
    val context = androidx.compose.ui.platform.LocalContext.current
    val scrollBehavior = MiuixScrollBehavior()
    val activity = context as? android.app.Activity

    var tick by remember { mutableStateOf(0) }
    var status by remember { mutableStateOf("") }
    var ok by remember { mutableStateOf(true) }
    val rows = remember {
        androidx.compose.runtime.mutableStateListOf<com.smallhairball.deepx.ProcessManagerActivity.Row>()
    }
    var actionRow by remember {
        mutableStateOf<com.smallhairball.deepx.ProcessManagerActivity.Row?>(null)
    }
    var toast by remember { mutableStateOf("") }

    androidx.compose.runtime.LaunchedEffect(tick) {
        status = runCatching {
            com.smallhairball.deepx.ProcessManagerActivity.readingStatus(context)
        }.getOrDefault("")
        runCatching {
            com.smallhairball.deepx.ProcessManagerActivity.load(
                activity,
                object : com.smallhairball.deepx.ProcessManagerActivity.ResultListener {
                    override fun onLoaded(success: Boolean, text: String, loaded: List<com.smallhairball.deepx.ProcessManagerActivity.Row>) {
                        ok = success
                        status = text
                        rows.clear()
                        rows.addAll(loaded)
                    }
                },
            )
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = "进程管理",
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                            contentDescription = "返回",
                            tint = colorScheme.onBackground,
                            modifier = Modifier.size(20.dp),
                        )
                    }
                },
                actions = {
                    TextButton(text = "刷新", onClick = { tick++ })
                },
                scrollBehavior = scrollBehavior,
            )
        },
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxHeight()
                .scrollEndHaptic()
                .overScrollVertical()
                .nestedScroll(scrollBehavior.nestedScrollConnection)
                .padding(horizontal = 12.dp),
            contentPadding = PaddingValues(
                top = innerPadding.calculateTopPadding() + 12.dp,
                bottom = innerPadding.calculateBottomPadding() + 24.dp,
            ),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            overscrollEffect = null,
        ) {
            item(key = "intro") {
                Text(
                    text = runCatching {
                        com.smallhairball.deepx.ProcessManagerActivity.intro(context)
                    }.getOrDefault(""),
                    style = MiuixTheme.textStyles.footnote1,
                    color = colorScheme.onSurfaceVariantSummary,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                )
            }
            item(key = "status") {
                Text(
                    text = status,
                    style = MiuixTheme.textStyles.footnote1,
                    color = if (ok) colorScheme.onSurfaceVariantSummary else colorScheme.error,
                    modifier = Modifier.padding(horizontal = 6.dp),
                )
            }
            items(rows.size, key = { rows[it].pid }) { index ->
                val row = rows[index]
                Card(
                    onClick = { actionRow = row },
                    modifier = Modifier.fillMaxWidth(),
                    showIndication = true,
                    pressFeedbackType = PressFeedbackType.Sink,
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = row.name,
                                style = MiuixTheme.textStyles.title4,
                                color = colorScheme.onSurface,
                            )
                            Spacer(Modifier.height(2.dp))
                            Text(
                                text = row.line,
                                style = MiuixTheme.textStyles.footnote1,
                                color = colorScheme.onSurfaceVariantSummary,
                            )
                        }
                        Spacer(Modifier.width(10.dp))
                        Text(
                            text = row.chip,
                            style = MiuixTheme.textStyles.footnote1,
                            color = if (row.frozen) colorScheme.error else colorScheme.primary,
                        )
                        Spacer(Modifier.width(6.dp))
                        Icon(
                            imageVector = Icons.AutoMirrored.Rounded.KeyboardArrowRight,
                            contentDescription = null,
                            tint = colorScheme.onSurfaceVariantSummary,
                            modifier = Modifier.size(20.dp),
                        )
                    }
                }
            }
        }
    }

    val target = actionRow
    if (target != null) {
        var actionShow by remember(target.pid) { mutableStateOf(true) }
        OverlayDialog(
            title = runCatching {
                com.smallhairball.deepx.ProcessManagerActivity.actionTitle(context)
            }.getOrDefault("进程操作"),
            show = actionShow,
            onDismissRequest = { actionShow = false },
            onDismissFinished = { actionRow = null },
        ) {
            Text(
                text = runCatching {
                    com.smallhairball.deepx.ProcessManagerActivity.actionDetail(context, target)
                }.getOrDefault(""),
                style = MiuixTheme.textStyles.footnote1,
                color = colorScheme.onSurfaceVariantSummary,
            )
            Spacer(Modifier.height(14.dp))
            Row(modifier = Modifier.fillMaxWidth()) {
                TextButton(
                    text = if (target.frozen) "解冻" else "冻结",
                    enabled = !target.self,
                    onClick = {
                        val action = if (target.frozen) "CONT" else "STOP"
                        com.smallhairball.deepx.ProcessManagerActivity.applyAction(
                            activity, target.pid, target.name.substringBefore(" "), action,
                            object : com.smallhairball.deepx.ProcessManagerActivity.ActionListener {
                                override fun onDone(success: Boolean, message: String) {
                                    if (success) tick++ else toast = message
                                }
                            },
                        )
                        actionShow = false
                    },
                    modifier = Modifier.weight(1f),
                )
                Spacer(Modifier.width(10.dp))
                TextButton(
                    text = "杀死",
                    onClick = {
                        com.smallhairball.deepx.ProcessManagerActivity.applyAction(
                            activity, target.pid, target.name.substringBefore(" "), "KILL",
                            object : com.smallhairball.deepx.ProcessManagerActivity.ActionListener {
                                override fun onDone(success: Boolean, message: String) {
                                    if (success) tick++ else toast = message
                                }
                            },
                        )
                        actionShow = false
                    },
                    modifier = Modifier.weight(1f),
                )
            }
        }
    }

    if (toast.isNotBlank()) {
        val scheme = MiuixTheme.colorScheme
        var toastShow by remember { mutableStateOf(true) }
        OverlayDialog(
            title = "提示",
            show = toastShow,
            onDismissRequest = { toastShow = false },
            onDismissFinished = { toast = "" },
        ) {
            Text(
                text = toast,
                style = MiuixTheme.textStyles.body2,
                color = scheme.onSurface,
            )
            Spacer(Modifier.height(12.dp))
            TextButton(
                text = "知道了",
                onClick = { toastShow = false },
                modifier = Modifier.fillMaxWidth(),
            )
        }
    }
}

/**
 * "DeepSeek native features" manager rendered with Miuix. The row matrix is driven by
 * {@code FeatureFlagsPageBridge}; each row opens a three-state picker (follow / force on /
 * force off). Risky rows surface the same warning the native page shows.
 */
@Composable
private fun FeatureFlagsPage(onBack: () -> Unit) {
    val colorScheme = MiuixTheme.colorScheme
    val context = androidx.compose.ui.platform.LocalContext.current
    val scrollBehavior = MiuixScrollBehavior()
    val summary = remember {
        runCatching {
            com.smallhairball.deepx.FeatureFlagsPageBridge.summary(context)
        }.getOrDefault("")
    }
    val rows = remember {
        androidx.compose.runtime.mutableStateListOf<com.smallhairball.deepx.FeatureFlagsPageBridge.Row>().apply {
            runCatching {
                addAll(
                    com.smallhairball.deepx.FeatureFlagsPageBridge.rows(
                        context as? android.app.Activity,
                    ),
                )
            }
        }
    }
    var activeRow by remember { mutableStateOf<com.smallhairball.deepx.FeatureFlagsPageBridge.Row?>(null) }
    var showReset by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = "DeepSeek 原生功能管理",
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                            contentDescription = "返回",
                            tint = colorScheme.onBackground,
                            modifier = Modifier.size(20.dp),
                        )
                    }
                },
                scrollBehavior = scrollBehavior,
            )
        },
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxHeight()
                .scrollEndHaptic()
                .overScrollVertical()
                .nestedScroll(scrollBehavior.nestedScrollConnection)
                .padding(horizontal = 12.dp),
            contentPadding = PaddingValues(
                top = innerPadding.calculateTopPadding() + 12.dp,
                bottom = innerPadding.calculateBottomPadding() + 24.dp,
            ),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            overscrollEffect = null,
        ) {
            item(key = "summary") {
                Text(
                    text = summary,
                    style = MiuixTheme.textStyles.footnote1,
                    color = colorScheme.onSurfaceVariantSummary,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp),
                )
            }
            items(rows.size, key = { rows[it].id }) { index ->
                val row = rows[index]
                Card(
                    onClick = { activeRow = row },
                    modifier = Modifier.fillMaxWidth(),
                    showIndication = true,
                    pressFeedbackType = PressFeedbackType.Sink,
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = row.title,
                                style = MiuixTheme.textStyles.title4,
                                color = colorScheme.onSurface,
                            )
                            if (row.subtitle.isNotBlank()) {
                                Spacer(Modifier.height(2.dp))
                                Text(
                                    text = row.subtitle,
                                    style = MiuixTheme.textStyles.footnote1,
                                    color = colorScheme.onSurfaceVariantSummary,
                                )
                            }
                        }
                        Spacer(Modifier.width(12.dp))
                        Text(
                            text = row.state,
                            style = MiuixTheme.textStyles.footnote1,
                            color = if (row.mode == 0) {
                                colorScheme.onSurfaceVariantSummary
                            } else {
                                colorScheme.primary
                            },
                        )
                    }
                }
            }
            item(key = "reset") {
                Card(
                    onClick = { showReset = true },
                    modifier = Modifier.fillMaxWidth(),
                    showIndication = true,
                    pressFeedbackType = PressFeedbackType.Sink,
                ) {
                    Text(
                        text = "全部恢复为跟随服务器",
                        modifier = Modifier.fillMaxWidth().padding(14.dp),
                        style = MiuixTheme.textStyles.title4,
                        color = colorScheme.primary,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                    )
                }
            }
        }
    }

    val active = activeRow
    if (active != null) {
        FeatureModeDialog(
            row = active,
            onClose = { activeRow = null },
            onSaved = { mode ->
                activeRow = null
                runCatching {
                    val fresh = com.smallhairball.deepx.FeatureFlagsPageBridge.rows(
                        context as? android.app.Activity,
                    )
                    rows.clear()
                    rows.addAll(fresh)
                }
            },
        )
    }

    if (showReset) {
        ConfirmDialog(
            title = "全部恢复为跟随服务器？",
            message = "会清除本模块写入的全部原生灰度覆盖，并重启 DeepSeek 让缓存重新加载。",
            negativeLabel = "取消",
            positiveLabel = "恢复并重启",
            onNegative = { showReset = false },
            onPositive = {
                showReset = false
                runCatching {
                    com.smallhairball.deepx.FeatureFlagsPageBridge.resetAll(
                        context as? android.app.Activity,
                    )
                }
            },
            verticalButtons = false,
            onDismissDialog = { showReset = false },
        )
    }
}

/**
 * Three-state picker for a single native feature (follow server / force on / force off).
 * Backed by {@code FeatureFlagsPageBridge}.
 */
@Composable
private fun FeatureModeDialog(
    row: com.smallhairball.deepx.FeatureFlagsPageBridge.Row,
    onClose: () -> Unit,
    onSaved: (Int) -> Unit,
) {
    val colorScheme = MiuixTheme.colorScheme
    val context = androidx.compose.ui.platform.LocalContext.current
    val options = remember(row.id) {
        runCatching {
            com.smallhairball.deepx.FeatureFlagsPageBridge.modeOptions(
                context as? android.app.Activity, row.id,
            )
        }.getOrDefault(emptyList())
    }
    val risk = remember(row.id) {
        if (row.risky) {
            runCatching {
                com.smallhairball.deepx.FeatureFlagsPageBridge.riskNote(
                    context as? android.app.Activity,
                )
            }.getOrDefault("")
        } else ""
    }
    val current = remember(row.id) {
        runCatching {
            com.smallhairball.deepx.FeatureFlagsPageBridge.currentMode(
                context as? android.app.Activity, row.id,
            )
        }.getOrDefault(0)
    }
    var show by remember { mutableStateOf(true) }
    var pending by remember { mutableStateOf<Int?>(null) }

    OverlayDialog(
        title = row.title,
        show = show,
        onDismissRequest = { show = false },
        onDismissFinished = {
            val value = pending
            if (value != null) onSaved(value) else onClose()
        },
    ) {
        if (risk.isNotBlank()) {
            Text(
                text = risk,
                style = MiuixTheme.textStyles.footnote1,
                color = colorScheme.error,
            )
            Spacer(Modifier.height(10.dp))
        }
        options.forEach { option ->
            Card(
                onClick = {
                    runCatching {
                        com.smallhairball.deepx.FeatureFlagsPageBridge.setMode(
                            context as? android.app.Activity, row.id, option.value,
                        )
                    }
                    pending = option.value
                    show = false
                },
                modifier = Modifier.fillMaxWidth(),
                showIndication = true,
                pressFeedbackType = PressFeedbackType.Sink,
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        text = option.label,
                        modifier = Modifier.weight(1f),
                        style = MiuixTheme.textStyles.title4,
                        color = colorScheme.onSurface,
                    )
                    if (option.value == current) {
                        Icon(
                            imageVector = Icons.Rounded.CheckCircleOutline,
                            contentDescription = null,
                            tint = colorScheme.primary,
                            modifier = Modifier.size(20.dp),
                        )
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
        }
    }
}

/**
 * Log-export sheet rendered with Miuix: uses the same sources and ZIP pipeline as
 * {@code com.smallhairball.deepx.LogExportUi}, but drawn as a Compose sheet.
 */
@Composable
private fun LogExportDialog(onClose: () -> Unit) {
    val colorScheme = MiuixTheme.colorScheme
    val context = androidx.compose.ui.platform.LocalContext.current
    val sources = remember {
        runCatching {
            com.smallhairball.deepx.DebugPageBridge.exportSources()
        }.getOrDefault(emptyList())
    }
    val checked = remember {
        mutableStateListOf<Boolean>().apply {
            sources.indices.forEach { add(it < 2) }
        }
    }
    val privacy = remember {
        runCatching {
            com.smallhairball.deepx.DebugPageBridge.exportPrivacyNote()
        }.getOrDefault("")
    }
    val exportLabel = remember {
        runCatching {
            com.smallhairball.deepx.DebugPageBridge.exportLabel()
        }.getOrDefault("导出")
    }
    var show by remember { mutableStateOf(true) }

    OverlayDialog(
        title = "导出日志",
        show = show,
        onDismissRequest = { show = false },
        onDismissFinished = onClose,
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(max = 360.dp)
                .verticalScroll(rememberScrollState()),
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                sources.forEachIndexed { index, source ->
                    Card(
                        onClick = {
                            if (index in checked.indices) checked[index] = !checked[index]
                        },
                        modifier = Modifier.fillMaxWidth(),
                        showIndication = true,
                        pressFeedbackType = PressFeedbackType.Sink,
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = source.name,
                                    style = MiuixTheme.textStyles.title4,
                                    color = colorScheme.onSurface,
                                )
                                Text(
                                    text = source.description,
                                    style = MiuixTheme.textStyles.footnote1,
                                    color = colorScheme.onSurfaceVariantSummary,
                                )
                            }
                            top.yukonga.miuix.kmp.basic.Switch(
                                checked = index in checked.indices && checked[index],
                                onCheckedChange = {
                                    if (index in checked.indices) checked[index] = it
                                },
                            )
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                }
                Spacer(Modifier.height(4.dp))
                Text(
                    text = privacy,
                    style = MiuixTheme.textStyles.footnote1,
                    color = colorScheme.onSurfaceVariantSummary,
                )
            }
        }
        Spacer(Modifier.height(12.dp))
        TextButton(
            text = exportLabel,
            onClick = {
                val selected = BooleanArray(sources.size)
                checked.forEachIndexed { index, value ->
                    if (index < selected.size) selected[index] = value
                }
                runCatching {
                    com.smallhairball.deepx.DebugPageBridge.startLogExport(
                        context as? android.app.Activity, selected,
                    )
                }
                show = false
            },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.textButtonColorsPrimary(),
        )
    }
}

/**
 * Crash-test picker rendered with Miuix: groups tests exactly like the legacy sheet and
 * delegates each trigger to {@code com.smallhairball.deepx.DebugPageBridge.triggerCrash}.
 */
@Composable
private fun CrashTestDialog(onClose: () -> Unit, onTrigger: (String) -> Unit) {
    val colorScheme = MiuixTheme.colorScheme
    val tests = remember {
        runCatching {
            com.smallhairball.deepx.DebugPageBridge.crashTests()
}.getOrDefault(emptyList())
    }
    var selectedGroup by remember { mutableStateOf<String?>(null) }
    var show by remember { mutableStateOf(true) }
    var pendingMode by remember { mutableStateOf<String?>(null) }
    val active = selectedGroup
    OverlayDialog(
        title = if (active == null) "崩溃测试" else active,
        show = show,
        onDismissRequest = { show = false },
        onDismissFinished = {
            val mode = pendingMode
            if (mode != null) onTrigger(mode) else onClose()
        },
    ) {
        if (active == null) {
            Text(
                text = "仅终止 DeepSeek 应用进程。已移除可能牵连系统冻结器的 Native 信号测试。",
                style = MiuixTheme.textStyles.footnote1,
                color = colorScheme.onSurfaceVariantSummary,
            )
            Spacer(Modifier.height(10.dp))
            tests.map { it.group }.distinct().forEach { group ->
                val hint = tests.firstOrNull { it.group == group }?.groupHint.orEmpty()
                Card(
                    onClick = { selectedGroup = group },
                    modifier = Modifier.fillMaxWidth(),
                    showIndication = true,
                    pressFeedbackType = PressFeedbackType.Sink,
                ) {
                    Column(modifier = Modifier.fillMaxWidth().padding(14.dp)) {
                        Text(
                            text = group,
                            style = MiuixTheme.textStyles.title4,
                            color = colorScheme.onSurface,
                        )
                        Text(
                            text = hint,
                            style = MiuixTheme.textStyles.footnote1,
                            color = colorScheme.onSurfaceVariantSummary,
                        )
                    }
                }
                Spacer(Modifier.height(8.dp))
            }
        } else {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 360.dp)
                    .verticalScroll(rememberScrollState()),
            ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    tests.filter { it.group == active }.forEach { test ->
                        Card(
                            onClick = { pendingMode = test.mode; show = false },
                            modifier = Modifier.fillMaxWidth(),
                            showIndication = true,
                            pressFeedbackType = PressFeedbackType.Sink,
                        ) {
                            Text(
                                text = test.title,
                                modifier = Modifier.fillMaxWidth().padding(14.dp),
                                style = MiuixTheme.textStyles.title4,
                                color = colorScheme.onSurface,
                            )
                        }
                        Spacer(Modifier.height(8.dp))
                    }
                }
            }
        }
    }
}

/**
 * Custom-request console rendered with Miuix: method toggle, path field, JSON body field and a
 * send button that delegates to {@code com.smallhairball.deepx.DebugPageBridge.sendRequest}.
 */
@Composable
private fun RequestDebugDialog(onClose: () -> Unit) {
    val colorScheme = MiuixTheme.colorScheme
    val context = androidx.compose.ui.platform.LocalContext.current
    val note = remember {
        runCatching {
            com.smallhairball.deepx.DebugPageBridge.requestNote()
        }.getOrDefault("")
    }
    val pathState = androidx.compose.foundation.text.input.rememberTextFieldState(
        runCatching {
            com.smallhairball.deepx.DebugPageBridge.requestDefaultPath()
        }.getOrDefault("/api/v0/users/current")
    )
    val bodyState = androidx.compose.foundation.text.input.rememberTextFieldState("")
    var method by remember { mutableStateOf("GET") }
    var show by remember { mutableStateOf(true) }

    OverlayDialog(
        title = "发送自定义请求",
        show = show,
        onDismissRequest = { show = false },
        onDismissFinished = onClose,
    ) {
        Text(
            text = note,
            style = MiuixTheme.textStyles.footnote1,
            color = colorScheme.onSurfaceVariantSummary,
        )
        Spacer(Modifier.height(12.dp))
        TextButton(
            text = "方法：$method（点击切换）",
            onClick = { method = if (method == "GET") "POST" else "GET" },
            modifier = Modifier.fillMaxWidth(),
        )
        Spacer(Modifier.height(8.dp))
        top.yukonga.miuix.kmp.basic.TextField(
            state = pathState,
            label = "路径（/api/…）",
            modifier = Modifier.fillMaxWidth(),
        )
        Spacer(Modifier.height(8.dp))
        top.yukonga.miuix.kmp.basic.TextField(
            state = bodyState,
            label = "POST 请求的 JSON 正文",
            modifier = Modifier.fillMaxWidth().heightIn(min = 96.dp),
        )
        Spacer(Modifier.height(12.dp))
        TextButton(
            text = "发送请求",
            onClick = {
                runCatching {
                    com.smallhairball.deepx.DebugPageBridge.sendRequest(
                        context as? android.app.Activity,
                        method,
                        pathState.text.toString(),
                        bodyState.text.toString(),
                    )
                }
                show = false
            },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.textButtonColorsPrimary(),
        )
    }
}

/** Home-greeting editor rendered with Miuix. Empty text restores DeepSeek's default. */
@Composable
private fun GreetingDialog(show: Boolean, onClose: () -> Unit) {
    val colorScheme = MiuixTheme.colorScheme
    val textState = androidx.compose.foundation.text.input.rememberTextFieldState("")
    var error by remember { mutableStateOf("") }

    OverlayDialog(
        title = "主页欢迎语",
        show = show,
        onDismissRequest = onClose,
    ) {
        Text(
            text = "留空则跟随 DeepSeek 默认文案。",
            style = MiuixTheme.textStyles.footnote1,
            color = colorScheme.onSurfaceVariantSummary,
        )
        Spacer(Modifier.height(10.dp))
        top.yukonga.miuix.kmp.basic.TextField(
            state = textState,
            label = "欢迎语",
            modifier = Modifier.fillMaxWidth(),
        )
        if (error.isNotBlank()) {
            Spacer(Modifier.height(8.dp))
            Text(
                text = error,
                style = MiuixTheme.textStyles.footnote1,
                color = colorScheme.error,
            )
        }
        Spacer(Modifier.height(12.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            TextButton(
                text = "取消",
                onClick = onClose,
                modifier = Modifier.weight(1f),
            )
            Spacer(Modifier.width(20.dp))
            TextButton(
                text = "保存",
                onClick = {
                    val ok = runCatching {
                        com.smallhairball.deepx.AppearancePageBridge.setGreeting(
                            textState.text.toString(),
                        )
                    }.getOrDefault(false)
                    if (ok) onClose() else error = "保存失败"
                },
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.textButtonColorsPrimary(),
            )
        }
    }
}

/** Slider tuning dialog rendered with Miuix (whale rotation / text-wave speed). */
@Composable
private fun SpeedDialog(
    show: Boolean,
    title: String,
    min: Float,
    max: Float,
    lowLabel: String,
    highLabel: String,
    initial: Float,
    onSave: (Float) -> Unit,
    onClose: () -> Unit,
) {
    val colorScheme = MiuixTheme.colorScheme
    var value by remember { mutableStateOf(initial.coerceIn(min, max)) }

    OverlayDialog(
        title = title,
        show = show,
        onDismissRequest = onClose,
    ) {
        Text(
            text = String.format(java.util.Locale.US, "%.1f×", value),
            modifier = Modifier.fillMaxWidth(),
            style = MiuixTheme.textStyles.title2,
            color = colorScheme.onSurface,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
        )
        Spacer(Modifier.height(8.dp))
        top.yukonga.miuix.kmp.basic.Slider(
            value = value,
            onValueChange = { value = it },
            valueRange = min..max,
            modifier = Modifier.fillMaxWidth(),
        )
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Text(
                text = lowLabel,
                style = MiuixTheme.textStyles.footnote1,
                color = colorScheme.onSurfaceVariantSummary,
            )
            Text(
                text = highLabel,
                style = MiuixTheme.textStyles.footnote1,
                color = colorScheme.onSurfaceVariantSummary,
            )
        }
        Spacer(Modifier.height(12.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            TextButton(
                text = "取消",
                onClick = onClose,
                modifier = Modifier.weight(1f),
            )
            Spacer(Modifier.width(20.dp))
            TextButton(
                text = "保存",
                onClick = {
                    runCatching { onSave(value) }
                    onClose()
                },
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.textButtonColorsPrimary(),
            )
        }
    }
}

/** Theme-colour dialog rendered with Miuix: enable switch plus two colour pickers. */
@Composable
private fun ThemeColorDialog(show: Boolean, onClose: () -> Unit) {
    val colorScheme = MiuixTheme.colorScheme
    var enabled by remember {
        mutableStateOf(runCatching {
            com.smallhairball.deepx.AppearancePageBridge.themeEnabled()
        }.getOrDefault(false))
    }
    var primary by remember {
        mutableStateOf(androidx.compose.ui.graphics.Color(
            runCatching { com.smallhairball.deepx.AppearancePageBridge.themePrimary() }
                .getOrDefault(0xFF4D6BFE.toInt())
        ))
    }
    var secondary by remember {
        mutableStateOf(androidx.compose.ui.graphics.Color(
            runCatching { com.smallhairball.deepx.AppearancePageBridge.themeSecondary() }
                .getOrDefault(0xFF8B5CF6.toInt())
        ))
    }

    OverlayDialog(
        title = "主题色",
        show = show,
        onDismissRequest = onClose,
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text("启用主题色", style = MiuixTheme.textStyles.title4)
                Text(
                    text = "应用到 DeepSeek 原生界面",
                    style = MiuixTheme.textStyles.footnote1,
                    color = colorScheme.onSurfaceVariantSummary,
                )
            }
            top.yukonga.miuix.kmp.basic.Switch(
                checked = enabled,
                onCheckedChange = { enabled = it },
            )
        }
        Spacer(Modifier.height(12.dp))
        Text(
            text = "主题颜色",
            style = MiuixTheme.textStyles.footnote1,
            color = colorScheme.onSurfaceVariantSummary,
        )
        Spacer(Modifier.height(6.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text("颜色一", style = MiuixTheme.textStyles.title4)
                Spacer(Modifier.height(6.dp))
                top.yukonga.miuix.kmp.basic.ColorPicker(
                    color = primary,
                    onColorChanged = { primary = it },
                    modifier = Modifier.fillMaxWidth(),
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    text = hexOf(primary),
                    modifier = Modifier.fillMaxWidth(),
                    style = MiuixTheme.textStyles.footnote1,
                    color = colorScheme.onSurfaceVariantSummary,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                )
            }
            Column(modifier = Modifier.weight(1f)) {
                Text("颜色二", style = MiuixTheme.textStyles.title4)
                Spacer(Modifier.height(6.dp))
                top.yukonga.miuix.kmp.basic.ColorPicker(
                    color = secondary,
                    onColorChanged = { secondary = it },
                    modifier = Modifier.fillMaxWidth(),
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    text = hexOf(secondary),
                    modifier = Modifier.fillMaxWidth(),
                    style = MiuixTheme.textStyles.footnote1,
                    color = colorScheme.onSurfaceVariantSummary,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                )
            }
        }
        Spacer(Modifier.height(14.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            TextButton(
                text = "取消",
                onClick = onClose,
                modifier = Modifier.weight(1f),
            )
            Spacer(Modifier.width(20.dp))
            TextButton(
                text = "保存",
                onClick = {
                    runCatching {
                        com.smallhairball.deepx.AppearancePageBridge.setThemeEnabled(enabled)
                        com.smallhairball.deepx.AppearancePageBridge.setThemeColors(
                            primary.toArgb(), secondary.toArgb(), true,
                        )
                    }
                    onClose()
                },
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.textButtonColorsPrimary(),
            )
        }
    }
}

private fun hexOf(color: androidx.compose.ui.graphics.Color): String =
    String.format(java.util.Locale.US, "#%08X", color.toArgb())

/** Assistant-avatar dialog rendered with Miuix. Files are picked through the module's own picker. */
@Composable
private fun AssistantAvatarDialog(show: Boolean, onClose: () -> Unit) {
    val colorScheme = MiuixTheme.colorScheme
    val context = androidx.compose.ui.platform.LocalContext.current
    var status by remember {
        mutableStateOf(
            if (runCatching {
                    com.smallhairball.deepx.AppearancePageBridge.hasCustomAvatar()
                }.getOrDefault(false)
            ) "当前使用自定义头像" else "当前使用 DeepSeek 默认头像"
        )
    }

    OverlayDialog(
        title = "自定义 DeepSeek 头像",
        show = show,
        onDismissRequest = onClose,
    ) {
        Text(
            text = status,
            modifier = Modifier.fillMaxWidth(),
            style = MiuixTheme.textStyles.title4,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
        )
        Spacer(Modifier.height(8.dp))
        Text(
            text = "需要在灰度功能管理里面开启“显示助手头像”，否则聊天页不会显示自定义头像。选择后返回聊天或重新进入会话即可生效。",
            style = MiuixTheme.textStyles.footnote1,
            color = colorScheme.onSurfaceVariantSummary,
        )
        Spacer(Modifier.height(14.dp))
        TextButton(
            text = "选择图片",
            onClick = {
                runCatching {
                    com.smallhairball.deepx.AppearancePageBridge.pickAvatar(
                        context as? android.app.Activity,
                    ) { message ->
                        if (message.isNotBlank()) status = message
                    }
                }
            },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.textButtonColorsPrimary(),
        )
        Spacer(Modifier.height(8.dp))
        TextButton(
            text = "关闭",
            onClick = onClose,
            modifier = Modifier.fillMaxWidth(),
        )
    }
}

/** A single account row rendered as a Miuix card. */
@Composable
private fun AccountRowCard(
    account: AccountItem,
    multiSelectMode: Boolean,
    selected: Boolean,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
) {
    val colorScheme = MiuixTheme.colorScheme
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .combinedClickable(onClick = onClick, onLongClick = onLongClick),
    ) {
        Card(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(2.dp),
                ) {
                    Text(account.label, style = MiuixTheme.textStyles.title4)
                    val sub = runCatching {
                        com.smallhairball.deepx.AccountsBridge.subtitle(account.provider)
                    }.getOrDefault("")
                    if (sub.isNotBlank()) {
                        Text(
                            text = sub,
                            style = MiuixTheme.textStyles.body2,
                            color = colorScheme.onSurfaceVariantSummary,
                        )
                    }
                }
                when {
                    multiSelectMode && selected -> Icon(
                        imageVector = Icons.Rounded.CheckCircleOutline,
                        contentDescription = "已选",
                        tint = colorScheme.primary,
                        modifier = Modifier.size(20.dp),
                    )
                    account.current -> Text(
                        text = "当前",
                        style = MiuixTheme.textStyles.footnote1,
                        color = colorScheme.primary,
                    )
                    else -> Icon(
                        imageVector = Icons.AutoMirrored.Rounded.KeyboardArrowRight,
                        contentDescription = null,
                        tint = colorScheme.onSurfaceVariantSummary,
                        modifier = Modifier.size(20.dp),
                    )
                }
            }
        }
    }
}

/**
 * Announcement dialog rendered with Miuix, shown by {@code DeePXHostLauncher.showAnnouncementDialog}.
 *
 * <p>Deliberately not a [ConfirmDialog]: there, dismissing by tapping outside is routed to the
 * negative action, which would silently and permanently mute the announcement. Here an outside tap
 * (or back) only closes the dialog, and the permanent "不再提醒" record is written exclusively by
 * the negative button.
 */
@Composable
fun AnnouncementDialog(
    title: String,
    body: String,
    onDismissDialog: () -> Unit,
    onMute: () -> Unit,
) {
    var show by remember { mutableStateOf(true) }
    var mute by remember { mutableStateOf(false) }

    OverlayDialog(
        title = title,
        show = show,
        onDismissRequest = { show = false },
        onDismissFinished = {
            onDismissDialog()
            if (mute) onMute()
        },
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            androidx.compose.foundation.text.selection.SelectionContainer {
                Text(
                    text = body,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Start,
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 360.dp)
                        .verticalScroll(rememberScrollState()),
                    style = MiuixTheme.textStyles.body2,
                    color = MiuixTheme.colorScheme.onSurfaceVariantSummary,
                )
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                TextButton(
                    text = "不再提醒",
                    onClick = {
                        mute = true
                        show = false
                    },
                    modifier = Modifier.weight(1f),
                )
                Spacer(Modifier.width(8.dp))
                TextButton(
                    text = "确定",
                    onClick = { show = false },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.textButtonColorsPrimary(),
                )
            }
        }
    }
}

/**
 * Generic Miuix confirm dialog used by the injected process. Shown through
 * {@code DeePXHostLauncher.showConfirmDialog} whenever a Java-side confirmation is requested.
 *
 * [show] is kept internally so the close animation can play: tapping a button flips it to false,
 * and only once the dialog has finished animating out do we dismiss the host Dialog and run the
 * side effect.
 */
@Composable
fun ConfirmDialog(
    title: String,
    message: String,
    negativeLabel: String?,
    positiveLabel: String,
    verticalButtons: Boolean,
    onDismissDialog: () -> Unit,
    onNegative: () -> Unit,
    onPositive: () -> Unit,
    dismissible: Boolean = true,
    keepOpenOnPositive: Boolean = false,
) {
    var show by remember { mutableStateOf(true) }
    var pending by remember { mutableStateOf<Runnable?>(null) }

    OverlayDialog(
        title = title,
        show = show,
        onDismissRequest = {
            if (dismissible && show) {
                pending = Runnable { onNegative() }
                show = false
            }
        },
        onDismissFinished = {
            onDismissDialog()
            val action = pending
            pending = null
            action?.run()
        },
    ) {
        Text(
            text = message,
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(max = 360.dp)
                .verticalScroll(rememberScrollState()),
            style = MiuixTheme.textStyles.body2,
            color = MiuixTheme.colorScheme.onSurfaceVariantSummary,
        )
        Spacer(Modifier.height(12.dp))
        if (verticalButtons) {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                if (negativeLabel != null) {
                    TextButton(
                        text = negativeLabel,
                        onClick = {
                            pending = Runnable { onNegative() }
                            show = false
                        },
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
                TextButton(
                    text = positiveLabel,
                    onClick = {
                        if (keepOpenOnPositive) {
                            onPositive()
                        } else {
                        pending = Runnable { onPositive() }
                        show = false
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.textButtonColorsPrimary(),
                )
            }
        } else {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                TextButton(
                    text = negativeLabel ?: "取消",
                    onClick = {
                        pending = Runnable { onNegative() }
                        show = false
                    },
                    modifier = Modifier.weight(1f),
                )
                Spacer(Modifier.width(20.dp))
                TextButton(
                    text = positiveLabel,
                    onClick = {
                        if (keepOpenOnPositive) {
                            onPositive()
                        } else {
                        pending = Runnable { onPositive() }
                        show = false
                        }
                    },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.textButtonColorsPrimary(),
                )
            }
        }
    }
}

/**
 * "Add account" dialog rendered with Miuix. Offers password login and native login, mirroring the
 * original two-branch dialog.
 */
/**
 * "执行" (task console) page rendered with Miuix. The job runs on the Java side
 * ({@code TaskConsoleBridge}) and this page polls its snapshot, so the streamed lines, the final
 * result and the save-log action stay in sync without a callback crossing into the View-only
 * module source tree. Reproduces the legacy console: monospace auto-scrolling log, a save action in
 * the top bar, a close button gated on completion and the result announced by its own dialog.
 *
 * <p>The hosting Dialog is created and shown by the Java caller, which also applies the shared
 * edge-to-edge system-bar treatment and the Activity push/pop window animation.
 */
@Composable
fun TaskConsoleScreen(
    fallbackTitle: String,
    fallbackHint: String,
    onClose: () -> Unit,
) {
    val colorScheme = MiuixTheme.colorScheme
    val context = androidx.compose.ui.platform.LocalContext.current
    val activity = context as? android.app.Activity
    val scrollBehavior = MiuixScrollBehavior()
    val logScroll = rememberScrollState()

    var snapshot by remember {
        mutableStateOf(
            runCatching { com.smallhairball.deepx.TaskConsoleBridge.snapshot() }.getOrNull()
        )
    }
    // The result is announced by its own dialog (like the legacy console did); this only tracks
    // whether the user already acknowledged it.
    var resultDismissed by remember { mutableStateOf(false) }

    // The console streams lines instead of reporting once, so poll while the job is running. The
    // session is started right after this dialog is attached, so keep polling briefly even when the
    // first snapshot still looks idle, and stop as soon as the job reports completion.
    LaunchedEffect(Unit) {
        var idleTicks = 0
        while (true) {
            val next = runCatching { com.smallhairball.deepx.TaskConsoleBridge.snapshot() }
                .getOrNull()
            snapshot = next
            if (next?.complete == true) break
            if (next?.running == true) {
                idleTicks = 0
            } else {
                idleTicks++
                if (idleTicks > 60) break
            }
            kotlinx.coroutines.delay(120L)
        }
    }

    // Keep the tail in view, like the legacy console's auto-scroll.
    LaunchedEffect(snapshot?.log) {
        logScroll.animateScrollTo(logScroll.maxValue)
    }

    val title = snapshot?.title?.takeIf { it.isNotBlank() } ?: fallbackTitle
    val done = snapshot?.complete == true
    val failed = snapshot?.failed == true
    val logText = snapshot?.log.orEmpty().ifBlank { fallbackHint }

    Scaffold(
        topBar = {
            TopAppBar(
                title = title.ifBlank { "执行" },
                navigationIcon = {
                    IconButton(onClick = { if (done) onClose() }) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                            contentDescription = "返回",
                            tint = colorScheme.onBackground,
                            modifier = Modifier.size(20.dp),
                        )
                    }
                },
                actions = {
                    TextButton(
                        text = "保存日志",
                        onClick = {
                            if (activity != null) {
                                runCatching {
                                    com.smallhairball.deepx.TaskConsoleBridge.saveLog(activity)
                                }
                            }
                            snapshot = runCatching {
                                com.smallhairball.deepx.TaskConsoleBridge.snapshot()
                            }.getOrNull()
                        },
                    )
                },
                scrollBehavior = scrollBehavior,
            )
        },
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(
                    start = 12.dp,
                    end = 12.dp,
                    top = innerPadding.calculateTopPadding() + 8.dp,
                    bottom = innerPadding.calculateBottomPadding() + 12.dp,
                ),
        ) {
            if (!done) {
                top.yukonga.miuix.kmp.basic.InfiniteProgressIndicator(
                    color = colorScheme.primary,
                    modifier = Modifier.fillMaxWidth(),
                )
                Spacer(Modifier.height(10.dp))
            }
            Card(modifier = Modifier.fillMaxWidth().weight(1f)) {
                androidx.compose.foundation.text.selection.SelectionContainer {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .verticalScroll(logScroll)
                            .padding(12.dp),
                    ) {
                        Text(
                            text = logText,
                            style = MiuixTheme.textStyles.footnote1.copy(
                                fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                                fontSize = 11.sp,
                                lineHeight = 16.sp,
                            ),
                            color = colorScheme.onSurface,
                        )
                    }
                }
            }
            // Mirror the legacy page: the result arrives as its own dialog instead of inline.
            if (done && snapshot?.hasResult() == true) {
                OverlayDialog(
                    title = if (failed) "执行失败" else title.ifBlank { "执行结果" },
                    show = !resultDismissed,
                    onDismissRequest = { resultDismissed = true },
                ) {
                    androidx.compose.foundation.text.selection.SelectionContainer {
                        Text(
                            text = snapshot?.result.orEmpty(),
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(max = 320.dp)
                                .verticalScroll(rememberScrollState())
                                .padding(bottom = 12.dp),
                            style = MiuixTheme.textStyles.body2,
                            color = colorScheme.onSurfaceVariantSummary,
                        )
                    }
                    TextButton(
                        text = "确定",
                        onClick = { resultDismissed = true },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.textButtonColorsPrimary(),
                    )
                }
            }
            if (done) {
                Spacer(Modifier.height(10.dp))
                TextButton(
                    text = "关闭",
                    onClick = onClose,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.textButtonColorsPrimary(),
                )
            }
        }
    }
}

/**
 * "Processing" dialog content rendered with Miuix: a title, an indeterminate progress indicator and
 * a stage label that cycles every [stageIntervalMs]. Shown by
 * {@code DeePXHostLauncher.showProgressDialog}.
 */
@Composable
fun ProgressDialogContent(
    title: String,
    stages: Array<String>,
    stageIntervalMs: Long,
) {
    var index by remember { mutableStateOf(0) }
    LaunchedEffect(Unit) {
        if (stages.size > 1) {
            while (true) {
                kotlinx.coroutines.delay(stageIntervalMs)
                index = (index + 1) % stages.size
            }
        }
    }
    OverlayDialog(
        title = title,
        show = true,
        onDismissRequest = {},
    ) {
        Text(
            text = stages.getOrElse(index) { "" },
            style = MiuixTheme.textStyles.body2,
            color = MiuixTheme.colorScheme.onSurfaceVariantSummary,
        )
        Spacer(Modifier.height(14.dp))
        top.yukonga.miuix.kmp.basic.InfiniteProgressIndicator(
            color = MiuixTheme.colorScheme.primary,
            modifier = Modifier.fillMaxWidth(),
        )
    }
}

@Composable
private fun AddAccountDialog(
    show: Boolean,
    onClose: () -> Unit,
    onPasswordLogin: () -> Unit,
    onNativeLogin: () -> Unit,
) {
    val colorScheme = MiuixTheme.colorScheme
    OverlayDialog(
        title = "添加账号",
        show = show,
        onDismissRequest = onClose,
    ) {
        Text(
            text = "当前账号不会被切换。可直接验证邮箱/手机号密码并加入候选列表，或使用原生登录页添加其他方式。",
            style = MiuixTheme.textStyles.body2,
            color = colorScheme.onSurfaceVariantSummary,
        )
        Spacer(Modifier.height(12.dp))
        TextButton(
            text = "密码登录",
            onClick = onPasswordLogin,
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.textButtonColorsPrimary(),
        )
        Spacer(Modifier.height(8.dp))
        TextButton(
            text = "原生登录页",
            onClick = onNativeLogin,
            modifier = Modifier.fillMaxWidth(),
        )
        Spacer(Modifier.height(8.dp))
        TextButton(
            text = "取消",
            onClick = onClose,
            modifier = Modifier.fillMaxWidth(),
        )
    }
}

/**
 * Password-login dialog rendered with Miuix. Identity/password are submitted through
 * {@code AccountsBridge.passwordAdd}; the result is reported back for status display.
 */
@Composable
private fun PasswordLoginDialog(
    show: Boolean,
    onClose: () -> Unit,
    onSubmit: (String, String, (Boolean, String) -> Unit) -> Unit,
) {
    val colorScheme = MiuixTheme.colorScheme
    val identityState = androidx.compose.foundation.text.input.rememberTextFieldState("")
    val passwordState = androidx.compose.foundation.text.input.rememberTextFieldState("")
    var status by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }

    OverlayDialog(
        title = "密码登录",
        show = show,
        onDismissRequest = onClose,
    ) {
        Text(
            text = "认证成功后只加入账号列表，不切换当前账号。密码不会保存。",
            style = MiuixTheme.textStyles.footnote1,
            color = colorScheme.onSurfaceVariantSummary,
        )
        Spacer(Modifier.height(10.dp))
        top.yukonga.miuix.kmp.basic.TextField(
            state = identityState,
            label = "邮箱或手机号",
            modifier = Modifier.fillMaxWidth(),
        )
        Spacer(Modifier.height(8.dp))
        top.yukonga.miuix.kmp.basic.TextField(
            state = passwordState,
            label = "密码",
            modifier = Modifier.fillMaxWidth(),
        )
        if (status.isNotBlank()) {
            Spacer(Modifier.height(8.dp))
            Text(
                text = status,
                style = MiuixTheme.textStyles.footnote1,
                color = colorScheme.primary,
            )
        }
        Spacer(Modifier.height(12.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            TextButton(
                text = "取消",
                onClick = onClose,
                modifier = Modifier.weight(1f),
            )
            Spacer(Modifier.width(20.dp))
            TextButton(
                text = if (busy) "验证中…" else "验证并添加",
                onClick = {
                    val identity = identityState.text.toString().trim()
                    val password = passwordState.text.toString()
                    if (identity.isEmpty() || password.isEmpty()) return@TextButton
                    busy = true
                    status = "正在通过 DeepSeek 原生链路验证…"
                    onSubmit(identity, password) { success, message ->
                        busy = false
                        status = message
                    }
                },
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.textButtonColorsPrimary(),
            )
        }
    }
}

@Composable
private fun ActivationCard(active: Boolean) {
    val colorScheme = MiuixTheme.colorScheme
    val container = if (active) colorScheme.tertiaryContainer else colorScheme.errorContainer
    val onContainer = if (active) colorScheme.onTertiaryContainer else colorScheme.onErrorContainer
    val accent = if (active) colorScheme.primary else colorScheme.error

    Card(
        modifier = Modifier.fillMaxWidth(),
        pressFeedbackType = PressFeedbackType.Tilt,
        colors = CardDefaults.defaultColors(
            color = container,
            contentColor = onContainer,
        ),
    ) {
        Box {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(27.dp, 31.dp),
                contentAlignment = Alignment.BottomEnd,
            ) {
                Icon(
                    imageVector = if (active) {
                        Icons.Rounded.CheckCircleOutline
                    } else {
                        Icons.Rounded.ErrorOutline
                    },
                    contentDescription = null,
                    tint = accent.copy(alpha = 0.35f),
                    modifier = Modifier.size(96.dp),
                )
            }
            Column(modifier = Modifier.fillMaxWidth().padding(16.dp, 18.dp)) {
                Text(
                    text = if (active) "模块已激活" else "模块未激活",
                    fontSize = 20.sp,
                    color = onContainer,
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    text = if (active) {
                        "DeePX 已在 DeepSeek 进程内注入并运行"
                    } else {
                        "未检测到注入，请在 LSPosed 中启用模块并勾选 DeepSeek"
                    },
                    fontSize = 13.sp,
                    color = onContainer.copy(alpha = 0.75f),
                )
            }
        }
    }
}

/** Card with an icon header and a stack of label/value rows. */
@Composable
private fun InfoPanel(icon: ImageVector, rows: List<Pair<String, String>>) {
    val colorScheme = MiuixTheme.colorScheme
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.fillMaxWidth().padding(16.dp)) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = colorScheme.primary,
                modifier = Modifier.size(24.dp),
            )
            Spacer(Modifier.height(16.dp))
            rows.forEachIndexed { index, row ->
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = if (index == rows.lastIndex) 0.dp else 18.dp),
                ) {
                    Text(
                        text = row.first,
                        style = MiuixTheme.textStyles.body2,
                        color = colorScheme.onSurfaceVariantSummary,
                    )
                    Spacer(Modifier.height(2.dp))
                    Text(
                        text = row.second.ifEmpty { "—" },
                        style = MiuixTheme.textStyles.body1,
                        color = colorScheme.onSurface,
                    )
                }
            }
        }
    }
}
